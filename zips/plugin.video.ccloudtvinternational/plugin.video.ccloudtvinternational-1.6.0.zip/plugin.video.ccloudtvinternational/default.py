# -*- coding: utf-8 -*-

"""
Copyright (C) 2016 PodGod

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
"""

import urllib, urllib2, sys, re, os, random, unicodedata, cookielib, shutil
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, requests, base64, urlparse, httplib, json

plugin_handle = int(sys.argv[1])
mysettings = xbmcaddon.Addon(id = 'plugin.video.ccloudtvinternational')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
getSetting = xbmcaddon.Addon().getSetting
enable_adult_section = mysettings.getSetting('enable_adult_section')

fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
iconpath = xbmc.translatePath(os.path.join(home, 'resources/icons/'))
icon = xbmc.translatePath(os.path.join(home, 'resources/icons/icon.png'))
addonDir = mysettings.getAddonInfo('path').decode("utf-8")

xml_regex = '<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
group_title_regex = 'group-title=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*'
eng_regex = '#(.+?),English,(.+)\s*(.+)\s*'
adult_regex = '#(.+?)group-title="Adult",(.+)\s*(.+)\s*'
adult_regex2 = '#(.+?)group-title="Public-Adult",(.+)\s*(.+)\s*'
ondemand_regex = '[ON\'](.*?)[\'nd]'
yt = 'http://www.youtube.com'
m3u = 'WVVoU01HTkViM1pNTTBKb1l6TlNiRmx0YkhWTWJVNTJZbE01ZVZsWVkzVmpSMmgzVURKck9WUlViRWxTYXpWNVZGUmpQUT09'.decode('base64')
text = 'http://pastebin.com/raw.php?i=Zr0Hgrbw'
GuideDirectory = xbmc.translatePath('special://home/userdata/addon_data/script.renegadestv/')
GuideINI = xbmc.translatePath('special://home/userdata/addon_data/script.renegadestv/addons2.ini')
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') )

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;
					
def read_file(file):
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass
		

def make_request():
	try:
		for server in shuffle(CCLOUDTV_SRV_URL):
			conn = GetHttpStatusAndData(server)
			if conn['valid']:
				links = conn['data'].encode('utf-8')
				return links
	except e:
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
	print 'All cCloud TV servers seem to be down. Please try again in a few minutes.'
	return None

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
			
def main():
	addDir('[COLOR red][B]Search[/B][/COLOR]', 'searchlink', 99, '%s/search.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Non-English/International[/B][/COLOR]', 'international', 64,'%s/international.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]By Country[/B][/COLOR]', 'bycountry', 100,'%s/bycountry.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]By Language[/B][/COLOR]', 'bylanguage', 101,'%s/bylanguage.png'% iconpath, fanart)
	addDir('[COLOR orange][B]M[/B][/COLOR][COLOR red][B]a[/B][/COLOR][COLOR skyblue][B]s[/B][/COLOR][COLOR lightgreen][B]h[/B][/COLOR][COLOR orange][B]u[/B][/COLOR][COLOR hotpink][B]p[/B][/COLOR]', 'Mashup', 102,'%s/mashup.png'% iconpath, fanart)

def checkregistered():
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URL = f.url

    if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
        lineworking = 'Registered'
    else:
        xbmcgui.Dialog().ok(addonname, 'Please Register your FnCable')
        sys.exit(0)
def createini():
	if not os.path.exists(GuideDirectory):
		dialog.ok(addon_id, 'Please make sure you have TV Guide installed and you have run it at least once then use this function to enable integration')
		dialog.notification(addonname, 'Please install and run TV Guide at least once', xbmcgui.NOTIFICATION_ERROR );
	
	if os.path.exists(GuideDirectory):
		addonsini = urllib.URLopener()
		addonsini.retrieve("https://raw.githubusercontent.com/podgod/podgod/master/cCloud_TV_Guide/XML/combined.ini", GuideINI)
        with open(GuideDirectory+"/addons2.ini", "a") as file:
            file.write('https://raw.githubusercontent.com/podgod/podgod/master/cCloud_TV_Guide/XML/combined.ini\n')
        shutil.rmtree(GuideDirectory , ignore_errors=True)
    	xbmc.executebuiltin("RunAddon(script.renegadestv)")
        sys.exit()
		
def removeAccents(s):
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
		
def search(): 	
	try:
		keyb = xbmc.Keyboard('', 'Enter Channel Name')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText(), safe="%/:=&?~#+!$,;'@()*[]").replace('+', ' ')
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					if '*Beware of scams' in name or '*Property of cCloudTV.ORG' in name or 'Welcome to cCloudTV.ORG' in name:
						pass
					else:
						m3u_playlist(name, url, thumb)
	except:
		pass
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);


def sports(): 	
	try:
		searchText = '(Sports)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	

def top10(): 	
	try:
		searchText = '(Top10)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
def news(): 	
	try:
		searchText = '(News)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
	
def documentary(): 	
	try:
		searchText = '(Document)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
	
def entertainment(): 	
	try:
		searchText = '(Entertainment)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
	
def family(): 	
	try:
		searchText = '(Family)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass


		
def lifestyle(): 	
	try:
		searchText = '(Lifestyle)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

		
	
def movie(): 	
	try:
		searchText = '(Movie Channels)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	


def music(): 	
	try:
		searchText = '(Music)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	

def ondemandmovies(): 	
	try:
		searchText = '(OnDemandMovies)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
	except:
		pass
	
def ondemandshows(): 	
	try:
		searchText = '(OnDemandShows)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
	except:
		pass
		

	
def twentyfour7(): 	
	try:
		searchText = '(RandomAirTime 24/7)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	

	
def radio(): 	
	try:
		searchText = '(Radio)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	

	
def adult(): 	
	try:
		searchText = ('(Adult)') or ('(Public-Adult)')
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(adult_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					adult_playlist(name, url, thumb)	
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(adult_regex2).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					adult_playlist(name, url, thumb)	

	except:
		pass
	
	
	
def english(): 	
	#addDir('[COLOR yellow][B]cCloud TV Guide[/B][/COLOR] - Click Here! Thanks to Renegades TV', 'guide', 97, '%s/guide.png'% iconpath, fanart)
	try:
		searchText = '(English)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content) 
			#file.write('\n'.join(match))
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
			#outfile.write("\n".join(addontest.ini))
	except:
		pass
	

def international(): 	
	try:
		searchGerman = '(German)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchGerman, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchSpanish = '(Spanish)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchSpanish, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchFrench = '(French)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchFrench, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchHindi = '(Hindi)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchHindi, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchArabic = '(Arabic)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchArabic, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchUrdu = '(Urdu)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchUrdu, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchFarsi = '(Farsi)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchFarsi, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchPortuguese = '(Portuguese)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchPortuguese, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchKurdish = '(Kurdish)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchKurdish, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchChinese = '(Chinese)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchChinese, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchSomali = '(Somali)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchSomali, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchRussian = '(Russian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchRussian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchAfrikaans = '(Afrikaans)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchAfrikaans, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchRomanian = '(Romanian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchRomanian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchItalian = '(Italian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchItalian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchIsraeli = '(Israeli)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchIsraeli, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchGreek = '(Greek)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchGreek, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchhungarian = '(Hungarian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchHungarian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchTamil = '(Tamil)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchTamil, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchMacedonian = '(Macedonian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchMacedonian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchIndian = '(Indian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchIndian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchCatalan = '(Catalan)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchCatalan, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchJamaica = '(Jamaica)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchJamaica, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchUkrainian = '(Ukrainian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchUkrainian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchVietamese = '(Vietamese)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchVietamese, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchMaltese = '(Maltese)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchMaltese, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchLithuanian = '(Lithuanian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchLithuanian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchPolish = '(Polish)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchPolish, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchSlovenian = '(Slovenian)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchSlovenian, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchDeutsch = '(Deutsch)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchDeutsch, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchDutch = '(Dutch)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchDutch, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchFilipino = '(Filipino)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchFilipino, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	try:
		searchMandarin = '(Mandarin)'
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchFilipino, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	

def bycountrycatogary():
	addDir('[COLOR royalblue][B]USA[/B][/COLOR]', 'USA', 500,'http://flags.fmcdn.net/data/flags/small/us.png', fanart)
	addDir('[COLOR royalblue][B]India[/B][/COLOR]', 'India', 501,'http://flags.fmcdn.net/data/flags/small/in.png', fanart)
	addDir('[COLOR royalblue][B]France[/B][/COLOR]', 'France', 502,'http://flags.fmcdn.net/data/flags/small/fr.png', fanart)
	addDir('[COLOR royalblue][B]Spain[/B][/COLOR]', 'Spain', 503,'http://flags.fmcdn.net/data/flags/small/es.png', fanart)
	addDir('[COLOR royalblue][B]Turkey[/B][/COLOR]', 'Turkey', 504,'http://flags.fmcdn.net/data/flags/small/tr.png', fanart)
	addDir('[COLOR royalblue][B]Australia[/B][/COLOR]', 'Australia', 505,'http://flags.fmcdn.net/data/flags/small/au.png', fanart)
	addDir('[COLOR royalblue][B]Brazil[/B][/COLOR]', 'Brazil', 506,'http://flags.fmcdn.net/data/flags/small/br.png', fanart)
	addDir('[COLOR royalblue][B]Germany[/B][/COLOR]', 'Germany', 507,'http://flags.fmcdn.net/data/flags/small/de.png', fanart)
	addDir('[COLOR royalblue][B]Argentina[/B][/COLOR]', 'Argentina', 508,'http://flags.fmcdn.net/data/flags/small/ar.png', fanart)
	addDir('[COLOR royalblue][B]Iraq[/B][/COLOR]', 'Iraq', 509,'http://flags.fmcdn.net/data/flags/small/iq.png', fanart)
	addDir('[COLOR royalblue][B]Syria[/B][/COLOR]', 'Syria', 510,'http://flags.fmcdn.net/data/flags/small/sy.png', fanart)
	addDir('[COLOR royalblue][B]Qatar[/B][/COLOR]', 'Qatar', 511,'http://flags.fmcdn.net/data/flags/small/qa.png', fanart)
	addDir('[COLOR royalblue][B]Libya[/B][/COLOR]', 'Libya', 512,'http://flags.fmcdn.net/data/flags/small/ly.png', fanart)
	addDir('[COLOR royalblue][B]Lebanon[/B][/COLOR]', 'Lebanon', 513,'http://flags.fmcdn.net/data/flags/small/lb.png', fanart)
	addDir('[COLOR royalblue][B]Canada[/B][/COLOR]', 'Canada', 514,'http://flags.fmcdn.net/data/flags/small/ca.png', fanart)
	addDir('[COLOR royalblue][B]Malaysia[/B][/COLOR]', 'Malaysia', 515,'http://flags.fmcdn.net/data/flags/small/my.png', fanart)
	addDir('[COLOR royalblue][B]UK[/B][/COLOR]', 'UK', 516,'http://flags.fmcdn.net/data/flags/small/gb.png', fanart)
	addDir('[COLOR royalblue][B]Bulgaria[/B][/COLOR]', 'Bulgaria', 517,'http://flags.fmcdn.net/data/flags/small/bg.png', fanart)
	addDir('[COLOR royalblue][B]Vietnam[/B][/COLOR]', 'Vietnam', 518,'http://flags.fmcdn.net/data/flags/small/vn.png', fanart)
	addDir('[COLOR royalblue][B]Indonesia[/B][/COLOR]', 'Indonesia', 519,'http://flags.fmcdn.net/data/flags/small/id.png', fanart)
	addDir('[COLOR royalblue][B]Mexico[/B][/COLOR]', 'Mexico', 520,'http://flags.fmcdn.net/data/flags/small/mx.png', fanart)
	addDir('[COLOR royalblue][B]Costa Rica[/B][/COLOR]', 'Costa Rica', 521,'http://flags.fmcdn.net/data/flags/small/cr.png', fanart)
	addDir('[COLOR royalblue][B]Egypt[/B][/COLOR]', 'Egypt', 522,'http://flags.fmcdn.net/data/flags/small/eg.png', fanart)
	addDir('[COLOR royalblue][B]Chile[/B][/COLOR]', 'Chile', 523,'http://flags.fmcdn.net/data/flags/small/cl.png', fanart)
	addDir('[COLOR royalblue][B]Honduras[/B][/COLOR]', 'Honduras', 524,'http://flags.fmcdn.net/data/flags/small/hn.png', fanart)
	addDir('[COLOR royalblue][B]Italy[/B][/COLOR]', 'Italy', 525,'http://flags.fmcdn.net/data/flags/small/it.png', fanart)
	addDir('[COLOR royalblue][B]Romania[/B][/COLOR]', 'Romania', 526,'http://flags.fmcdn.net/data/flags/small/ro.png', fanart)
	addDir('[COLOR royalblue][B]Pakistan[/B][/COLOR]', 'Pakistan', 527,'http://flags.fmcdn.net/data/flags/small/pk.png', fanart)
	addDir('[COLOR royalblue][B]Portugal[/B][/COLOR]', 'Portugal', 528,'http://flags.fmcdn.net/data/flags/small/pt.png', fanart)
	addDir('[COLOR royalblue][B]China[/B][/COLOR]', 'China', 529,'http://flags.fmcdn.net/data/flags/small/ch.png', fanart)
	addDir('[COLOR royalblue][B]Somalia[/B][/COLOR]', 'Somalia', 530,'http://flags.fmcdn.net/data/flags/small/so.png', fanart)
	addDir('[COLOR royalblue][B]Iran[/B][/COLOR]', 'Iran', 531,'http://flags.fmcdn.net/data/flags/small/ir.png', fanart)
	addDir('[COLOR royalblue][B]Russia[/B][/COLOR]', 'Russia', 532,'http://flags.fmcdn.net/data/flags/small/ru.png', fanart)
	addDir('[COLOR royalblue][B]Palestine[/B][/COLOR]', 'Palestine', 533,'https://s-media-cache-ak0.pinimg.com/736x/91/a4/6e/91a46e8bb5bb10b6a8a471ef990ec814.jpg', fanart)
	addDir('[COLOR royalblue][B]Sri Lanka[/B][/COLOR]', 'Sri Lanka', 534,'http://flags.fmcdn.net/data/flags/small/lk.png', fanart)
	addDir('[COLOR royalblue][B]Oman[/B][/COLOR]', 'Oman', 535,'http://flags.fmcdn.net/data/flags/small/om.png', fanart)
	addDir('[COLOR royalblue][B]Saudi Arabia[/B][/COLOR]', 'Saudi Arabia', 536,'http://flags.fmcdn.net/data/flags/small/sa.png', fanart)
	addDir('[COLOR royalblue][B]Ireland[/B][/COLOR]', 'Ireland', 537,'http://flags.fmcdn.net/data/flags/small/ie.png', fanart)
	addDir('[COLOR royalblue][B]Thailand[/B][/COLOR]', 'Thailand', 538,'http://flags.fmcdn.net/data/flags/small/th.png', fanart)
	addDir('[COLOR royalblue][B]Nigeria[/B][/COLOR]', 'Nigeria', 539,'http://flags.fmcdn.net/data/flags/small/ng.png', fanart)
	addDir('[COLOR royalblue][B]Maldives[/B][/COLOR]', 'Maldives', 540,'http://flags.fmcdn.net/data/flags/small/mv.png', fanart)
	addDir('[COLOR royalblue][B]Kenya[/B][/COLOR]', 'Kenya', 541,'http://flags.fmcdn.net/data/flags/small/ke.png', fanart)
	addDir('[COLOR royalblue][B]United Arab Emirates[/B][/COLOR]', 'United Arabic Emirates', 542,'http://flags.fmcdn.net/data/flags/small/ae.png', fanart)
	addDir('[COLOR royalblue][B]Colombia[/B][/COLOR]', 'Colombia', 543,'http://flags.fmcdn.net/data/flags/small/co.png', fanart)
	addDir('[COLOR royalblue][B]Israel[/B][/COLOR]', 'Israel', 544,'http://flags.fmcdn.net/data/flags/small/il.png', fanart)
	addDir('[COLOR royalblue][B]Guatemala[/B][/COLOR]', 'Guatemala', 545,'http://flags.fmcdn.net/data/flags/small/gt.png', fanart)
	addDir('[COLOR royalblue][B]Afghanistan[/B][/COLOR]', 'Afghanistan', 546,'http://flags.fmcdn.net/data/flags/small/af.png', fanart)
	addDir('[COLOR royalblue][B]Macedonia[/B][/COLOR]', 'Macedonia', 547,'http://flags.fmcdn.net/data/flags/small/mk.png', fanart)
	addDir('[COLOR royalblue][B]Bangladesh[/B][/COLOR]', 'Bangladesh', 548,'http://flags.fmcdn.net/data/flags/small/bd.png', fanart)
	addDir('[COLOR royalblue][B]Greece[/B][/COLOR]', 'Greece', 549,'http://flags.fmcdn.net/data/flags/small/gr.png', fanart)
	addDir('[COLOR royalblue][B]Guyana[/B][/COLOR]', 'Guyana', 550,'http://flags.fmcdn.net/data/flags/small/gy.png', fanart)
	addDir('[COLOR royalblue][B]Northern Ireland[/B][/COLOR]', 'Northern Ireland', 551,'https://upload.wikimedia.org/wikipedia/commons/7/7f/St_Patrick_Northern_Ireland_Flag.png', fanart)
	addDir('[COLOR royalblue][B]Barbados[/B][/COLOR]', 'Barbados', 552,'http://flags.fmcdn.net/data/flags/small/bb.png', fanart)
	addDir('[COLOR royalblue][B]Trinidad and Tobago[/B][/COLOR]', 'Trinidad and Tobago', 553,'http://flags.fmcdn.net/data/flags/small/tt.png', fanart)
	addDir('[COLOR royalblue][B]Dominican Republic[/B][/COLOR]', 'Dominican Republic', 554,'http://flags.fmcdn.net/data/flags/small/do.png', fanart)
	addDir('[COLOR royalblue][B]Ecuador[/B][/COLOR]', 'Ecuador', 555,'http://flags.fmcdn.net/data/flags/small/ec.png', fanart)
	addDir('[COLOR royalblue][B]Jamaica[/B][/COLOR]', 'Jamaica', 556,'http://flags.fmcdn.net/data/flags/small/jm.png', fanart)
	addDir('[COLOR royalblue][B]Cameroon[/B][/COLOR]', 'Cameroon', 557,'http://flags.fmcdn.net/data/flags/small/cm.png', fanart)
	addDir('[COLOR royalblue][B]Jordan[/B][/COLOR]', 'Jordan', 558,'http://flags.fmcdn.net/data/flags/small/jo.png', fanart)
	addDir('[COLOR royalblue][B]Malta[/B][/COLOR]', 'Malta', 559,'http://flags.fmcdn.net/data/flags/small/mt.png', fanart)
	addDir('[COLOR royalblue][B]Dominica[/B][/COLOR]', 'Dominica', 560,'http://flags.fmcdn.net/data/flags/small/dm.png', fanart)
	addDir('[COLOR royalblue][B]Albania[/B][/COLOR]', 'Albania', 561,'http://flags.fmcdn.net/data/flags/small/al.png', fanart)
	addDir('[COLOR royalblue][B]Puerto Rico[/B][/COLOR]', 'Puerto Rico', 562,'http://ecx.images-amazon.com/images/I/41EW81K3AVL._SX355_.jpg', fanart)
	addDir('[COLOR royalblue][B]Japan[/B][/COLOR]', 'Japan', 563,'http://flags.fmcdn.net/data/flags/small/jp.png', fanart)
	addDir('[COLOR royalblue][B]Bosnia and Herzegovina[/B][/COLOR]', 'Bosnia and Herzegovina', 564,'http://flags.fmcdn.net/data/flags/small/ba.png', fanart)
	addDir('[COLOR royalblue][B]Morocco[/B][/COLOR]', 'Morocco', 565,'http://flags.fmcdn.net/data/flags/small/ma.png', fanart)
	addDir('[COLOR royalblue][B]Poland[/B][/COLOR]', 'Poland', 566,'http://www.spilxperten.com/resourceloader.aspx?fileId=12dff6b6-100a-4c53-8924-96f52ad38736', fanart)
	addDir('[COLOR royalblue][B]Venezuela[/B][/COLOR]', 'Venezuela', 566,'http://www.spilxperten.com/resourceloader.aspx?fileId=12dff6b6-100a-4c53-8924-96f52ad38736', fanart)
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);

def GetchannelsCountry(name): 
	if name == '[COLOR royalblue][B]USA[/B][/COLOR]':
		name = '(US)'	
	if name == '[COLOR royalblue][B]India[/B][/COLOR]':
		name = '(IN)'	
	if name == '[COLOR royalblue][B]France[/B][/COLOR]':
		name = '(FR)'	
	if name == '[COLOR royalblue][B]Spain[/B][/COLOR]':
		name = '(ES)'	
	if name == '[COLOR royalblue][B]Turkey[/B][/COLOR]':
		name = '(TR)'	
	if name == '[COLOR royalblue][B]Australia[/B][/COLOR]':
		name = '(AU)'	
	if name == '[COLOR royalblue][B]Brazil[/B][/COLOR]':
		name = '(BR)'	
	if name == '[COLOR royalblue][B]Germany[/B][/COLOR]':
		name = '(DE)'	
	if name == '[COLOR royalblue][B]Argentina[/B][/COLOR]':
		name = '(AR)'	
	if name == '[COLOR royalblue][B]Iraq[/B][/COLOR]':
		name = '(IQ)'	
	if name == '[COLOR royalblue][B]Syria[/B][/COLOR]':
		name = '(SY)'	
	if name == '[COLOR royalblue][B]Qatar[/B][/COLOR]':
		name = '(QA)'	
	if name == '[COLOR royalblue][B]Libya[/B][/COLOR]':
		name = '(LY)'	
	if name == '[COLOR royalblue][B]Lebanon[/B][/COLOR]':
		name = '(LB)'	
	if name == '[COLOR royalblue][B]Canada[/B][/COLOR]':
		name = '(CA)'	
	if name == '[COLOR royalblue][B]Malaysia[/B][/COLOR]':
		name = '(MY)'	
	if name == '[COLOR royalblue][B]UK[/B][/COLOR]':
		name = '(UK)'	
	if name == '[COLOR royalblue][B]Bulgaria[/B][/COLOR]':
		name = '(BG)'	
	if name == '[COLOR royalblue][B]Vietnam[/B][/COLOR]':
		name = '(VN)'	
	if name == '[COLOR royalblue][B]Indonesia[/B][/COLOR]':
		name = '(ID)'	
	if name == '[COLOR royalblue][B]Mexico[/B][/COLOR]':
		name = '(MX)'	
	if name == '[COLOR royalblue][B]Costa Rica[/B][/COLOR]':
		name = '(CR)'	
	if name == '[COLOR royalblue][B]Egypt[/B][/COLOR]':
		name = '(EG)'	
	if name == '[COLOR royalblue][B]Chile[/B][/COLOR]':
		name = '(CL)'	
	if name == '[COLOR royalblue][B]Honduras[/B][/COLOR]':
		name = '(HN)'	
	if name == '[COLOR royalblue][B]Italy[/B][/COLOR]':
		name = '(IT)'	
	if name == '[COLOR royalblue][B]Romania[/B][/COLOR]':
		name = '(RO)'	
	if name == '[COLOR royalblue][B]Pakistan[/B][/COLOR]':
		name = '(PK)'	
	if name == '[COLOR royalblue][B]Portugal[/B][/COLOR]':
		name = '(PT)'	
	if name == '[COLOR royalblue][B]China[/B][/COLOR]':
		name = '(CH)'	
	if name == '[COLOR royalblue][B]Somalia[/B][/COLOR]':
		name = '(SO)'	
	if name == '[COLOR royalblue][B]Iran[/B][/COLOR]':
		name = '(IR)'	
	if name == '[COLOR royalblue][B]Russia[/B][/COLOR]':
		name = '(RU)'	
	if name == '[COLOR royalblue][B]Palestine[/B][/COLOR]':
		name = '(PS)'	
	if name == '[COLOR royalblue][B]Sri Lanka[/B][/COLOR]':
		name = '(LK)'	
	if name == '[COLOR royalblue][B]Oman[/B][/COLOR]':
		name = '(OM)'	
	if name == '[COLOR royalblue][B]Saudi Arabia[/B][/COLOR]':
		name = '(SA)'	
	if name == '[COLOR royalblue][B]Ireland[/B][/COLOR]':
		name = '(IE)'	
	if name == '[COLOR royalblue][B]Thailand[/B][/COLOR]':
		name = '(TH)'	
	if name == '[COLOR royalblue][B]Nigeria[/B][/COLOR]':
		name = '(NG)'	
	if name == '[COLOR royalblue][B]Maldives[/B][/COLOR]':
		name = '(MV)'	
	if name == '[COLOR royalblue][B]Kenya[/B][/COLOR]':
		name = '(KE)'	
	if name == '[COLOR royalblue][B]United Arab Emirates[/B][/COLOR]':
		name = '(AE)'	
	if name == '[COLOR royalblue][B]Colombia[/B][/COLOR]':
		name = '(CO)'	
	if name == '[COLOR royalblue][B]Israel[/B][/COLOR]':
		name = '(IL)'	
	if name == '[COLOR royalblue][B]Guatemala[/B][/COLOR]':
		name = '(GT)'	
	if name == '[COLOR royalblue][B]Afghanistan[/B][/COLOR]':
		name = '(AF)'	
	if name == '[COLOR royalblue][B]Macedonia[/B][/COLOR]':
		name = '(MK)'	
	if name == '[COLOR royalblue][B]Bangladesh[/B][/COLOR]':
		name = '(BD)'	
	if name == '[COLOR royalblue][B]Greece[/B][/COLOR]':
		name = '(GR)'	
	if name == '[COLOR royalblue][B]Northern Ireland[/B][/COLOR]':
		name = '(IE)'	
	if name == '[COLOR royalblue][B]Barbados[/B][/COLOR]':
		name = '(BB)'	
	if name == '[COLOR royalblue][B]Trinidad and Tobago[/B][/COLOR]':
		name = '(TT)'	
	if name == '[COLOR royalblue][B]Dominican Republic[/B][/COLOR]':
		name = '(DO)'	
	if name == '[COLOR royalblue][B]Ecuador[/B][/COLOR]':
		name = '(EC)'	
	if name == '[COLOR royalblue][B]Jamaica[/B][/COLOR]':
		name = '(JM)'	
	if name == '[COLOR royalblue][B]Venezuela[/B][/COLOR]':
		name = '(VE)'	
	if name == '[COLOR royalblue][B]Cameroon[/B][/COLOR]':
		name = '(CM)'	
	if name == '[COLOR royalblue][B]Jordan[/B][/COLOR]':
		name = '(JO)'	
	if name == '[COLOR royalblue][B]Malta[/B][/COLOR]':
		name = '(MT)'	
	if name == '[COLOR royalblue][B]Dominica[/B][/COLOR]':
		name = '(DM)'	
	if name == '[COLOR royalblue][B]Albania[/B][/COLOR]':
		name = '(AL)'	
	if name == '[COLOR royalblue][B]Puerto Rico[/B][/COLOR]':
		name = '(PR)'	
	if name == '[COLOR royalblue][B]Japan[/B][/COLOR]':
		name = '(JP)'	
	if name == '[COLOR royalblue][B]Bosnia and Herzegovina[/B][/COLOR]':
		name = '(BA)'	
	if name == '[COLOR royalblue][B]Morocco[/B][/COLOR]':
		name = '(MA)'	
	if name == '[COLOR royalblue][B]Poland[/B][/COLOR]':
		name = '(PL)'	

	try:
		searchText = name
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content) 
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE) and searchText in name:
					if '*Beware of scams' in name or '*Property of cCloudTV.ORG' in name or 'Welcome to cCloudTV.ORG' in name:
						pass
					else:
						m3u_playlist(name, url, thumb)
	except:
		pass

def bylanguagecatogary():
	addDir('[COLOR royalblue][B]English[/B][/COLOR]', 'English', 600, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]French[/B][/COLOR]', 'French', 601, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Spanish[/B][/COLOR]', 'Spanish', 602, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Turkish[/B][/COLOR]', 'Turkish', 603, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Hindi[/B][/COLOR]', 'Hindi', 604, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Telugu[/B][/COLOR]', 'Telugu', 605, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Portuguese[/B][/COLOR]', 'Portuguese', 606, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]German[/B][/COLOR]', 'German', 607, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Arabic[/B][/COLOR]', 'Arabic', 608, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Syrian[/B][/COLOR]', 'Syrian', 609, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Russian[/B][/COLOR]', 'Russian', 610, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Assamese[/B][/COLOR]', 'Assamese', 611, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Kannada[/B][/COLOR]', 'Kannada', 612, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Indonesian[/B][/COLOR]', 'Indonesian', 613, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Vietnamese[/B][/COLOR]', 'Vietnamese', 614, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Bulgarian[/B][/COLOR]', 'Bulgarian', 615, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Italian[/B][/COLOR]', 'Italian', 616, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Punjabi[/B][/COLOR]', 'Punjabi', 617, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Urdu[/B][/COLOR]', 'Urdu', 618, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Mandarin[/B][/COLOR]', 'Mandarin', 619, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Somali[/B][/COLOR]', 'Somali', 620, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Persian[/B][/COLOR]', 'Persian', 621, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Marathi[/B][/COLOR]', 'Marathi', 622, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Tamil[/B][/COLOR]', 'Tamil', 623, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Korean[/B][/COLOR]', 'Korean', 624, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Kurdish[/B][/COLOR]', 'Kurdish', 625, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Oriya[/B][/COLOR]', 'Oriya', 626, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Bengali[/B][/COLOR]', 'Bengali', 627, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Romanian[/B][/COLOR]', 'Romanian', 628, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Thai[/B][/COLOR]', 'Thai', 629, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Gujarati[/B][/COLOR]', 'Gujarati', 630, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Malayalam[/B][/COLOR]', 'Malayalam', 631, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Israeli[/B][/COLOR]', 'Israeli', 632, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Pashto[/B][/COLOR]', 'Pashto', 633, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Greek[/B][/COLOR]', 'Greek', 634, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Sinhalese[/B][/COLOR]', 'Sinhalese', 635, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Afrikaans[/B][/COLOR]', 'Afrikaans', 636, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Pashto[/B][/COLOR]', 'Pashto', 637, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Catalan[/B][/COLOR]', 'Catalan', 638, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Jamaican[/B][/COLOR]', 'Jamaican', 639, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Maltese[/B][/COLOR]', 'Maltese', 640, '%s/languages.png'% iconpath, fanart)
	addDir('[COLOR royalblue][B]Japanese[/B][/COLOR]', 'Japanese', 641, '%s/languages.png'% iconpath, fanart)
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);

def GetchannelsLanguage(name): 
	name = name.replace("[COLOR royalblue][B]", "")
	name = name.replace("[/B][/COLOR]", "")

	try:
		searchText = name
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content) 
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE) and searchText in name:
					if '*Beware of scams' in name or '*Property of cCloudTV.ORG' in name or 'Welcome to cCloudTV.ORG' in name:
						pass
					else:
						m3u_playlist(name, url, thumb)
	except:
		pass

def Getchannelsinternational(): 
#	name = name.replace("[COLOR royalblue][B]", "")
#	name = name.replace("[/B][/COLOR]", "")

	try:
		searchText = ' '
		if len(CCLOUDTV_SRV_URL) > 0:		
			content = make_request()
			match = re.compile(m3u_regex).findall(content) 
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE) and searchText in name:
					if '*Beware of scams' in name or '*Property of cCloudTV.ORG' in name or 'Welcome to cCloudTV.ORG' in name or '(English)' in name:
						pass
					else:
						m3u_playlist(name, url, thumb)
	except:
		pass
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);

custom_mac = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_mac_1")
custom_server = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_server_1")
if custom_server == '5':
	custom_mac = '00:1A:78:'+custom_mac
	customportalserver = 'http://portal.iptvrocket.tv/'
if custom_server == '6':
	custom_mac = '00:1A:79:'+custom_mac
	customportalserver = 'http://portal1.iptvrocket.tv/'
custom_login = xbmcaddon.Addon('plugin.video.stalker').getSetting("login_1")
custom_portal = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_name_1")

def StalkerChannels():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_cCloud'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_cCloud'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
#       title = title.encode("utf-8")
        cmd = v["cmd"]
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'FnCable'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")

#       xbmcgui.Dialog().ok(__addonname__, title)
	
        liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
        liz.setInfo( type="Video",  infoLabels={ "Title": title} )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

#	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def text_online():		
	text = '[COLOR royalblue][B]***Latest Announcements***[/B][/COLOR]'
	newstext = 'http://pastebin.com/raw.php?i=7K3zDiZ2'
	req = urllib2.Request(newstext)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	match=re.compile("<START>(.+?)<END>",re.DOTALL).findall(link)
	for status in match:
	    try:
			    status = status.decode('ascii', 'ignore')
	    except:
			    status = status.decode('utf-8','ignore')
	    status = status.replace('&amp;','')
	    text = status
	showText('[COLOR royalblue][B]***Latest Announcements***[/B][/COLOR]', text)

def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
	try:
	    xbmc.sleep(10)
	    retry -= 1
	    win.getControl(1).setLabel(heading)
	    win.getControl(5).setText(text)
	    return
	except:
	    pass

def guide():
	dialog = xbmcgui.Dialog()
	ret = dialog.yesno('cCloud TV Guide', '[COLOR yellow]cCloud TV[/COLOR] is now integrated with your favourite TV Guides.','This is currently in beta and not all channels are supported.','[COLOR yellow]>>>>>>>>>>>>>  Choose Your Guide Below  <<<<<<<<<<<<<[/COLOR]','iVue TV Guide','Renegades TV Guide')
	if ret == 1:
			xbmc.executebuiltin("RunAddon(script.renegadestv)")
			sys.exit()
	if ret == 0:
			xbmc.executebuiltin("RunAddon(script.ivueguide)")
			sys.exit()
	else:
			sys.exit()
	
def m3u_online():		
	content = make_request()
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass
		

def m3u_playlist(name, url, thumb):	
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			addDir(name, url, '', thumb, thumb)			
		else:	
			addDir(name, url, '', icon, fanart)
	else:
		if ('(Adult)' in name) or ('(Public-Adult)' in name):
			name = 'ADULTS ONLY'.url = 'http://ignoreme.com'
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		#elif 'dailymotion.com/video/' in url:
		#	url = url.split('/')[-1].split('_')[0]
		#	url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			addLink(name, url, 1, thumb, thumb)			
		else:				
			addLink(name, url, 1, icon, fanart)	
			
			
def adult_playlist(name, url, thumb):	
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			addDir(name, url, '', thumb, thumb)		
		else:	
			addDir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		#elif 'dailymotion.com/video/' in url:
		#	url = url.split('/')[-1].split('_')[0]
		#	url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			addLink(name, url, 1, thumb, thumb)			
		else:				
			addLink(name, url, 1, icon, fanart)	

def play_video(url):

	if 'parser.php?surl=' in url: # case for cCloudTv redirecting parser
		try:
			#print 'URL: ' + str(url)
			if '|' in url:
				urls = url.split('|')
				rurl = str(urls[0])
				purl = urls[1]
			else:
				rurl = url
			req = urllib2.Request(rurl)
			res = urllib2.urlopen(req)
			furl = res.geturl()
			if '|' in url:
				url = furl + '|' + purl
			else:
				url = furl
			#print 'RedirectorURL: ' + str(url)
		except:
			pass
			
	media_url = url
	item = xbmcgui.ListItem(name, path = media_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return
	
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

ini = 'YUhSMGNEb3ZMMnR2WkdsbGNHY3VZMk5zWkM1cGJ3PT0='.decode('base64').decode('base64')
List1 = 'YUhSMGNEb3ZMM2d1WTI4dlpHSmphREF4'.decode('base64').decode('base64')
List2 = 'YUhSMGNEb3ZMMnR2WkdrdVkyTnNaQzVwYnc9PQ=='.decode('base64').decode('base64')
List3 = 'YUhSMGNEb3ZMMkZwYnk1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVE9PQ=='.decode('base64').decode('base64')
List4 = 'YUhSMGNEb3ZMMmR2TW13dWFXNXJMMnR2WkdrPQ=='.decode('base64').decode('base64')
List5 = 'YUhSMGNEb3ZMM051YVhBdWJHa3ZhMjlrYVE9PQ=='.decode('base64').decode('base64')
List6 = 'YUhSMGNEb3ZMMk5rYmk1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVRFPQ=='.decode('base64').decode('base64')
List7 = 'YUhSMGNEb3ZMMk5rYmk1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVRJPQ=='.decode('base64').decode('base64')
List8 = 'YUhSMGNEb3ZMMk5rYmk1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVRNPQ=='.decode('base64').decode('base64')
List9 = 'YUhSMGNEb3ZMMk5rYmk1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVRRPQ=='.decode('base64').decode('base64')
List10 = 'YUhSMGNEb3ZMMk5rYmk1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVRVPQ=='.decode('base64').decode('base64')
List11= 'YUhSMGNEb3ZMMkZwY2k1alkyeHZkV1IwZGk1dmNtY3ZhMjlrYVE9PQ=='.decode('base64').decode('base64')

CCLOUDTV_SRV_URL = [List1,List2,List3,List4,List5,List6,List7,List8,List9,List10,List11]

####################################################################################################
# Gets the data and tests for a valid M3U since a 200 response code can still lead to an empty file 
# or a different page but not our listing
def GetHttpStatusAndData(url):

	resp = {}
	resp['valid'] = False
	resp['data'] = ''
	try:
		hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
   'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
   'Accept-Encoding': 'none',
   'Accept-Language': 'en-US,en;q=0.8',
   'Connection': 'keep-alive'}
   
		req = urllib2.Request(url, headers=hdr)
		response = urllib2.urlopen(req)
		
		data = response.read()
		if '#EXTM3U' in data:
			resp['valid'] = True
			resp['data'] = data

	except urllib2.HTTPError, e:
		pass

	return resp

####################################################################################################
# Randomizes the order of items in a list
def shuffle(mlist):
	result = []
	cloneList = []
	for item in mlist:
		cloneList.append(item)
	for i in range(len(cloneList)):
		element = random.choice(cloneList)
		cloneList.remove(element)
		result.append(element)
	return result

def addDir(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok

def addLink(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)  
		
params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)		

#xbmcgui.Dialog().ok(addonname, str(mode))

if mode == None or url == None or len(url) < 1:
	checkregistered()
	main()

elif mode == 1:
	play_video(url)

elif mode == 2:
	m3u_online()
	
elif mode == 3:
	text_online()
	
	
elif mode == 51:
	top10()
		
elif mode == 52:
	sports()
	
elif mode == 53:
	news()
	
elif mode == 54:
	documentary()
	
elif mode == 55:
	entertainment()
	
elif mode == 56:
	family()
	
elif mode == 57:
	movie()
	
elif mode == 58:
	music()
	
elif mode == 59:
	ondemandmovies()
	
elif mode == 65:
	ondemandshows()
	
elif mode == 60:
	twentyfour7()
	
elif mode == 61:
	radio()
	
elif mode == 62:
	english()

elif mode == 63:
	lifestyle()
	
elif mode == 64:
	Getchannelsinternational()
	
elif mode==95:
    createini()
		
elif mode == 97:
	guide()
	
elif mode == 98:
	adult()
	
elif mode == 99:
	search()

elif mode == 100:
	bycountrycatogary()

elif mode == 101:
	bylanguagecatogary()

elif mode == 102:
	StalkerChannels()
	Getchannelsinternational()

elif mode >= 500 and mode <= 599:
	GetchannelsCountry(name)

elif mode >= 600 and mode <= 699:
	GetchannelsLanguage(name)
	
xbmcplugin.endOfDirectory(plugin_handle)