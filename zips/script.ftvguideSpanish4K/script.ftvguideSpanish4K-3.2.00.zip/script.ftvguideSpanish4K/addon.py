# -*- coding: utf-8 -*-
#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified for FTV Guide (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcaddon
import time

time = 2000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.ftvguideSpanish4K')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Cargando Por Favor Esperar'
xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))

import gui

import os
import sys
import xbmcgui
import urllib2
import httplib
import re

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/addon_data/script.ftvguideSpanish4K/'
    )

inifolder = xbmc.translatePath(
    'special://home/userdata/addon_data/script.ftvguideSpanish4K/addons_'+custom_key+'.ini'
    )

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/ftvspanishtemp.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

import urllib
urllib.urlretrieve (MAIN_URL+'addons.ini', TARGETFOLDER+'addons_'+custom_key+'.ini')

registermessage1 = "FnCable no está activado"
registermessage2 = "Activar FnCable se encuentra en el submenú de energía. Consulte Cómo obtener instrucciones de activación."

line1 = 'Conexion a la Nube FnCable Abrio'
failedline = 'FnCable 700+ Channels Live TV – English Guide – Espanol Guia available now with $100/yr subscription (Box update required).'

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
else:
	xbmcgui.Dialog().ok(__addonname__, registermessage1, registermessage2)

try:
    w = gui.TVGuide()
    w.doModal()
    del w

except:
    import sys
    import traceback as tb
    (etype, value, traceback) = sys.exc_info()
    tb.print_exception(etype, value, traceback)