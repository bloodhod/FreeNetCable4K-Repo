# -*- coding: cp1254 -*-
# please visit http://www.iptvxtra.net
# -*- encoding:utf8 -*-

mainurl="http://freenetcable.com/live/test/SpanishStreams.xml"

import base64
import cookielib,sys
import urllib2,urllib,re,os
import urlparse
import httplib

import sqlite3

from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
import resources.lib.requests as requests
import xbmcplugin,xbmcgui,xbmc,xbmcaddon 

from datetime import tzinfo, timedelta, datetime
import xml.etree.ElementTree as ET
import pdb, time,json

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'albums')
Addon = xbmcaddon.Addon('plugin.video.fncabletv')
addon_id = 'plugin.video.fncabletv'
selfAddon = xbmcaddon.Addon(id=addon_id)
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
addonsettings = xbmcaddon.Addon(id='plugin.video.fncabletv')
__language__ = addonsettings.getLocalizedString
home = addonsettings.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
code1 = 'http://nix02.'

__addon__ = xbmcaddon.Addon('plugin.video.fncabletv')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
time = 6000 #in miliseconds

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'Loading Please Wait', time, __icon__))

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/Database/'
    )

try:
 response = urllib2.urlopen('http://s.IPTVxtra.net/code02')
 for codex in response:
  c = codex 
 c = c.strip()
 c = c.replace('&key=','')
 c = c.partition("code=")
 code2 = c[2]
except:
 code2 = 'xxxxxxxxxxxxx'

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;

def parseTime(info):
    naive,offset=info.split()
    t_tmp = datetime.strptime(naive, '%Y%m%d%H%M%S')
    offSign = offset[0]
    offHrs = int(offset[1:3])
    offMins = int(offset[-2:])
    td = timedelta(minutes=offMins, hours=offHrs)
    if offSign == '+':
        t = t_tmp - td
    elif offSign == '-':
        t = t_tmp + td
    else:
        t = t_tmp
    return t

# ==========================================================set_param

DB_FILE_PATH = TARGETFOLDER+'Epg10.db'
Channel_name = 'HBO 2 West'

Query = """
    select sTitle/*, 
            datetime(iStartTime, 'unixepoch') , 
            datetime(iEndTime, 'unixepoch')*/
    from EPG
    join epgtags
    using(idEpg)
    where sName = '%s'
    and datetime(iEndTime, 'unixepoch') > current_timestamp
    order by datetime(iStartTime, 'unixepoch')
    LIMIT 2
"""

def parse_timestamp(ts):
    #returns 
    return datetime.utcfromtimestamp(float(ts))
    
def get_shows_for_channel(id):
    with open(jsonFilePath) as f:
        jsonData = json.load(f)
    channels = jsonData['js']['data']
    showsList = channels[id]
    return sorted(showsList, key = lambda k: parse_timestamp(k['start_timestamp']))

def get_current_and_next_shows(ch_id):
    channelShows = get_shows_for_channel(ch_id)

    for i, show in enumerate(channelShows):
        showStartTime = parse_timestamp(show['start_timestamp'])
        showEndTime = parse_timestamp(show['stop_timestamp'])
        
        if showEndTime >= currentTime >= showStartTime:
            nowshow = show
            print 'Current show is: ', show['name']
            
            if i+1 == len(channelShows): nextshow = None
            else: 
                nextshow = channelShows[i+1]
                print 'Next show is: ', nextshow['name']
            break
                
    return nowshow, nextshow

def main():
    url = mainurl
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            addLink(videoTitle,url,thumbnail)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def addLink(name,url,iconimage):
        ok=True
        if 'giniko' in url:
            url = ginico(url)
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def ginico(url):
    x = url.partition('---')
    url = x[0]
    id = x[2].replace('xxx','')
    r = requests.get("http://giniko.com/watch.php?id=" + id)
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=37")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=220")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    else: return url

FileName = TARGETFOLDER+'Output.txt'

if os.path.exists(FileName):
    getkey = open(TARGETFOLDER+'Output.txt').read()
    MAIN_URL = base64.b64decode(getkey)

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if not os.path.exists(FileName):
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/fncabletv.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URL = f.url
    encoded = base64.b64encode(MAIN_URL)
    text_file = open(TARGETFOLDER+"Output.txt", "w")
    text_file.write(encoded)
    text_file.close()
    getkey = open(TARGETFOLDER+'Output.txt').read()
    MAIN_URL = base64.b64decode(getkey)
else:
    getkey = open(TARGETFOLDER+'Output.txt').read()
    MAIN_URL = base64.b64decode(getkey)

if mode is None:

    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URL = f.url

    if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
        lineworking = 'Registered'
    else:
        xbmcgui.Dialog().ok(__addonname__, 'Please Register your FnCable')
        sys.exit(0)

    url = build_url({'mode': 'English', 'foldername': 'English'})
    li = xbmcgui.ListItem('English', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish', 'foldername': 'Spanish'})
    li = xbmcgui.ListItem('Spanish', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Search', 'foldername': 'Search'})
    li = xbmcgui.ListItem('Search', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'English':
    url = MAIN_URL+"EnglishStreams1.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 2', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 2':
    url = MAIN_URL+"EnglishStreams2.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 3', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 3':
    url = MAIN_URL+"EnglishStreams3.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 4', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 4':
    url = MAIN_URL+"EnglishStreams4.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 5', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 5':
    url = MAIN_URL+"EnglishStreams5.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 6', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 6':
    url = MAIN_URL+"EnglishStreams6.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 7', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 7':
    url = MAIN_URL+"EnglishStreams7.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 8', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 8':
    url = MAIN_URL+"EnglishStreams8.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 9', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 9':
    url = MAIN_URL+"EnglishStreams9.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'English Page 10', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English Page 10':
    url = MAIN_URL+"EnglishStreams10.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass
#            try:
#                chid = thumbnail.replace("http://portal.iptvrocket.tv/stalker_portal/misc/logos/320/","")
#                chid = chid.replace(".png","")
#            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass
#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'English Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish':
    url = MAIN_URL+"SpanishStreams1.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 2':
    url = MAIN_URL+"SpanishStreams2.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 3':
    url = MAIN_URL+"SpanishStreams3.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 4':
    url = MAIN_URL+"SpanishStreams4.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 5':
    url = MAIN_URL+"SpanishStreams5.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 6':
    url = MAIN_URL+"SpanishStreams6.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 7':
    url = MAIN_URL+"SpanishStreams7.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 8':
    url = MAIN_URL+"SpanishStreams8.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Page 10'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 10'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 9':
    url = MAIN_URL+"SpanishStreams9.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)

    url = build_url({'mode': 'Spanish Page 10', 'foldername': 'Next Page'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Next Page'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish Page 10':
    url = MAIN_URL+"SpanishStreams10.xml"
    link=get_url(url)
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                url=item.link.string
                if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
            except: pass
            try:
                thumbnail=item.thumbnail.string
            except: pass

            try:
                with sqlite3.connect(DB_FILE_PATH) as connection:
                    ch_name = videoTitle
                    cursor = connection.cursor()
                    cursor.execute(Query%ch_name)
                    data = cursor.fetchall()
                    if len(data) == 0: 
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        raise ValueError('No current shows for channel %s'%ch_name)
                    elif len(data) == 1:
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                        print 'no next show'
                    else:
                        nowshow, nextshow = data
                        nowshowline = nowshow[0]
                        nextshowline = nextshow[0]
                        videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
#                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
            except: pass

#            xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

            liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
#            addLink(videoTitle,url,thumbnail)
    url = build_url({'mode': 'Spanish Page 1', 'foldername': 'Page 1'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 1'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 2', 'foldername': 'Page 2'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 2'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 3', 'foldername': 'Page 3'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 3'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 4', 'foldername': 'Page 4'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 4'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 5', 'foldername': 'Page 5'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 5'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 6', 'foldername': 'Page 6'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 6'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 7', 'foldername': 'Page 7'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 7'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 8', 'foldername': 'Page 8'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 8'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish Page 9', 'foldername': 'Page 9'})
    li = xbmcgui.ListItem('[COLOR FFF1F1F1]'+'Page 9'+'[/COLOR]', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Search':
    url = MAIN_URL+"AllStreams.xml"
    link=get_url(url)

    kb = xbmc.Keyboard('', 'Enter the Channel Name')
    kb.doModal()
    if kb.isConfirmed():
        enteredvalue = kb.getText()
        enteredvalue1 = enteredvalue[:1].upper() + enteredvalue[1:]
        enteredvalue2 = enteredvalue.upper()
    
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
                if enteredvalue in videoTitle or enteredvalue1 in videoTitle or enteredvalue2 in videoTitle:
                    try:
                        url=item.link.string
                        if 'totiptv' in url: url = code1 + url + '?oid=1&pt=3&dt=1&ra=1&code=' + code2 + '&key='
                        #url = url + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'
                    except: pass
                    try:
                        thumbnail=item.thumbnail.string
                    except: pass

                    try:
                        with sqlite3.connect(DB_FILE_PATH) as connection:
                            ch_name = videoTitle
                            cursor = connection.cursor()
                            cursor.execute(Query%ch_name)
                            data = cursor.fetchall()
                            if len(data) == 0: 
                                videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                                raise ValueError('No current shows for channel %s'%ch_name)
                            elif len(data) == 1:
                                videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'
                                print 'no next show'
                            else:
                                nowshow, nextshow = data
                                nowshowline = nowshow[0]
                                nextshowline = nextshow[0]
                                videoTitle = '[COLOR FFF1F1F1]'+videoTitle+'[/COLOR]'+'[COLOR orange]'+' Now '+'[/COLOR]'+'[COLOR FFF1F1F1]'+nowshowline+'[/COLOR]'
        #                        xbmcgui.Dialog().ok(__addonname__, nowshow[0])
                    except: pass
#                    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);

                    liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
                    liz.setInfo( type="Video",  infoLabels={ "Title": videoTitle} )
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)            
        #            addLink(videoTitle,url,thumbnail)
            except: pass
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
