# -*- coding: cp1254 -*-
# please visit http://www.iptvxtra.net

mainurl="http://freenetcable.com/live/test/uk-streams.xml"

import sys
import urllib
import urlparse
import base64
import cookielib,sys
import urllib2,urllib,re,os
import json
import hashlib
import pdb
import httplib

import xbmcplugin,xbmcgui,xbmc,xbmcaddon 

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'albums')
Addon = xbmcaddon.Addon('plugin.video.fncabletv')
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
addonsettings = xbmcaddon.Addon(id='plugin.video.fncabletv')
__language__ = addonsettings.getLocalizedString
home = addonsettings.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
code1 = 'http://nix02.'

TARGETFOLDERaddon = xbmc.translatePath(
'special://home/addons/plugin.video.fncabletv/'
)

libDir = os.path.join(TARGETFOLDERaddon, 'resources', 'lib')
sys.path.insert(0, libDir)
import common

__addon__ = xbmcaddon.Addon('script.ftvguideIndia')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
addon       = xbmcaddon.Addon('plugin.video.stalker')
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key)
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
    lineworking = 'Registered'
else:
    xbmcgui.Dialog().ok(__addonname__, 'Please Register your FnCable')
    sys.exit(0)

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/fncabletv.php?key='+custom_key)
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

TARGETFOLDER = xbmc.translatePath(
'special://home/userdata/addon_data/plugin.video.fncabletv/'
)

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

custom_mac = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_mac_1")
portal_name = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_name_1")
parental = xbmcaddon.Addon('plugin.video.stalker').getSetting("parental")

addonurl = 'plugin://plugin.video.stalker/?'
name = portal_name
parental = parental
url = 'http://portal.iptvprivateserver.tv'
mac = custom_mac
serialmode = 'custom'
serialvalue = 'false'
password = '0000'

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;

try:
 response = urllib2.urlopen('http://s.IPTVxtra.net/code02')
 for codex in response:
  c = codex 
 c = c.strip()
 c = c.replace('&key=','')
 c = c.partition("code=")
 code2 = c[2]
except:
 code2 = 'xxxxxxxxxxxxx'

urllib.urlretrieve (MAIN_URL+'http_portal_iptvprivateserver_tv', TARGETFOLDER+'http_portal_iptvprivateserver_tv')
urllib.urlretrieve (MAIN_URL+'http_portal_iptvprivateserver_tv_english', TARGETFOLDER+'http_portal_iptvprivateserver_tv_english')
urllib.urlretrieve (MAIN_URL+'http_portal_iptvprivateserver_tv_spanish', TARGETFOLDER+'http_portal_iptvprivateserver_tv_spanish')
urllib.urlretrieve (MAIN_URL+'http_portal_iptvprivateserver_tv_indian', TARGETFOLDER+'http_portal_iptvprivateserver_tv_indian')
urllib.urlretrieve (MAIN_URL+'http_portal_iptvprivateserver_tv_music', TARGETFOLDER+'http_portal_iptvprivateserver_tv_music')
urllib.urlretrieve (MAIN_URL+'http_portal_iptvprivateserver_tv_adult', TARGETFOLDER+'http_portal_iptvprivateserver_tv_adult')

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def ginico(url):
    x = url.partition('---')
    url = x[0]
    id = x[2].replace('xxx','')
    r = requests.get("http://giniko.com/watch.php?id=" + id)
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=37")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=220")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    else: return url

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'All', 'foldername': 'All'})
    li = xbmcgui.ListItem('All', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'BlackandWhite', 'foldername': 'Black And White'})
    li = xbmcgui.ListItem('Black And White', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'English', 'foldername': 'English'})
    li = xbmcgui.ListItem('English', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Indian', 'foldername': 'Indian'})
    li = xbmcgui.ListItem('Indian', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Music', 'foldername': 'Music'})
    li = xbmcgui.ListItem('Music', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Spanish', 'foldername': 'Spanish'})
    li = xbmcgui.ListItem('Spanish', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Adult', 'foldername': 'XXX - Over 18'})
    li = xbmcgui.ListItem('XXX - Over 18', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'All':
    foldername = args['foldername'][0]
    with open(TARGETFOLDER+"http_portal_iptvprivateserver_tv") as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        try:
            videoTitle = v["name"]
            title = videoTitle
        except: pass
        try:
            genre_name = 'All'
        except: pass
        try:
            cmd = v["cmd"]
        except: pass
        try:
            tmp = v["tmp"]
        except: pass
        try:
            logo = v["logo"]
            logo_url = 'http://portal.iptvprivateserver.tv/stalker_portal/misc/logos/320/'+logo
            thumbnail = logo_url
        except: pass
        try:
            url = 'http://portal.iptvprivateserver.tv'
            portal_string = '{"name": "%s", "parental": "%s", "url": "%s", "mac": "%s", "serial": {"%s": %s}, "password": "%s"}'%(name,parental,url,mac,serialmode,serialvalue,password)
            raw_url = "tmp=%s&genre_name=['%s']&title=%s&cmd=%s&portal=%s&mode=play&logo_url=%s"%(tmp,genre_name,title,cmd,portal_string,logo_url)
            url = addonurl + urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
        except: pass

#        xbmcgui.Dialog().ok(__addonname__, url)
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);

#        addLink(videoTitle,url,thumbnail)
#        xbmc.executebuiltin("Container.SetSortMethod(7)");
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": videoTitle } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'English':
    foldername = args['foldername'][0]
    with open(TARGETFOLDER+"http_portal_iptvprivateserver_tv_english") as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        try:
            videoTitle = v["name"]
            title = videoTitle
        except: pass
        try:
            genre_name = 'All'
        except: pass
        try:
            cmd = v["cmd"]
        except: pass
        try:
            tmp = v["tmp"]
        except: pass
        try:
            logo = v["logo"]
            logo_url = 'http://portal.iptvprivateserver.tv/stalker_portal/misc/logos/320/'+logo
            thumbnail = logo_url
        except: pass
        try:
            url = 'http://portal.iptvprivateserver.tv'
            portal_string = '{"name": "%s", "parental": "%s", "url": "%s", "mac": "%s", "serial": {"%s": %s}, "password": "%s"}'%(name,parental,url,mac,serialmode,serialvalue,password)
            raw_url = "tmp=%s&genre_name=['%s']&title=%s&cmd=%s&portal=%s&mode=play&logo_url=%s"%(tmp,genre_name,title,cmd,portal_string,logo_url)
            url = addonurl + urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
        except: pass

#        xbmcgui.Dialog().ok(__addonname__, url)
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);

#        addLink(videoTitle,url,thumbnail)
#        xbmc.executebuiltin("Container.SetSortMethod(7)");
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": videoTitle } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Spanish':
    foldername = args['foldername'][0]
    with open(TARGETFOLDER+"http_portal_iptvprivateserver_tv_spanish") as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        try:
            videoTitle = v["name"]
            title = videoTitle
        except: pass
        try:
            genre_name = 'All'
        except: pass
        try:
            cmd = v["cmd"]
        except: pass
        try:
            tmp = v["tmp"]
        except: pass
        try:
            logo = v["logo"]
            logo_url = 'http://portal.iptvprivateserver.tv/stalker_portal/misc/logos/320/'+logo
            thumbnail = logo_url
        except: pass
        try:
            url = 'http://portal.iptvprivateserver.tv'
            portal_string = '{"name": "%s", "parental": "%s", "url": "%s", "mac": "%s", "serial": {"%s": %s}, "password": "%s"}'%(name,parental,url,mac,serialmode,serialvalue,password)
            raw_url = "tmp=%s&genre_name=['%s']&title=%s&cmd=%s&portal=%s&mode=play&logo_url=%s"%(tmp,genre_name,title,cmd,portal_string,logo_url)
            url = addonurl + urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
        except: pass

#        xbmcgui.Dialog().ok(__addonname__, url)
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);

#        addLink(videoTitle,url,thumbnail)
#        xbmc.executebuiltin("Container.SetSortMethod(7)");
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": videoTitle } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Indian':
    foldername = args['foldername'][0]
    with open(TARGETFOLDER+"http_portal_iptvprivateserver_tv_indian") as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        try:
            videoTitle = v["name"]
            title = videoTitle
        except: pass
        try:
            genre_name = 'All'
        except: pass
        try:
            cmd = v["cmd"]
        except: pass
        try:
            tmp = v["tmp"]
        except: pass
        try:
            logo = v["logo"]
            logo_url = 'http://portal.iptvprivateserver.tv/stalker_portal/misc/logos/320/'+logo
            thumbnail = logo_url
        except: pass
        try:
            url = 'http://portal.iptvprivateserver.tv'
            portal_string = '{"name": "%s", "parental": "%s", "url": "%s", "mac": "%s", "serial": {"%s": %s}, "password": "%s"}'%(name,parental,url,mac,serialmode,serialvalue,password)
            raw_url = "tmp=%s&genre_name=['%s']&title=%s&cmd=%s&portal=%s&mode=play&logo_url=%s"%(tmp,genre_name,title,cmd,portal_string,logo_url)
            url = addonurl + urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
        except: pass

#        xbmcgui.Dialog().ok(__addonname__, url)
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);

#        addLink(videoTitle,url,thumbnail)
#        xbmc.executebuiltin("Container.SetSortMethod(7)");
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": videoTitle } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Adult':
    foldername = args['foldername'][0]
    with open(TARGETFOLDER+"http_portal_iptvprivateserver_tv_adult") as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        try:
            videoTitle = v["name"]
            title = videoTitle
        except: pass
        try:
            genre_name = 'All'
        except: pass
        try:
            cmd = v["cmd"]
        except: pass
        try:
            tmp = v["tmp"]
        except: pass
        try:
            logo = v["logo"]
            logo_url = 'http://portal.iptvprivateserver.tv/stalker_portal/misc/logos/320/'+logo
            thumbnail = logo_url
        except: pass
        try:
            url = 'http://portal.iptvprivateserver.tv'
            portal_string = '{"name": "%s", "parental": "%s", "url": "%s", "mac": "%s", "serial": {"%s": %s}, "password": "%s"}'%(name,parental,url,mac,serialmode,serialvalue,password)
            raw_url = "tmp=%s&genre_name=['%s']&title=%s&cmd=%s&portal=%s&mode=play&logo_url=%s"%(tmp,genre_name,title,cmd,portal_string,logo_url)
            url = addonurl + urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
        except: pass

#        xbmcgui.Dialog().ok(__addonname__, url)
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);

#        addLink(videoTitle,url,thumbnail)
#        xbmc.executebuiltin("Container.SetSortMethod(7)");
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": videoTitle } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'Music':
    foldername = args['foldername'][0]
    with open(TARGETFOLDER+"http_portal_iptvprivateserver_tv_music") as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        try:
            videoTitle = v["name"]
            title = videoTitle
        except: pass
        try:
            genre_name = 'All'
        except: pass
        try:
            cmd = v["cmd"]
        except: pass
        try:
            tmp = v["tmp"]
        except: pass
        try:
            logo = v["logo"]
            logo_url = 'http://portal.iptvprivateserver.tv/stalker_portal/misc/logos/320/'+logo
            thumbnail = logo_url
        except: pass
        try:
            url = 'http://portal.iptvprivateserver.tv'
            portal_string = '{"name": "%s", "parental": "%s", "url": "%s", "mac": "%s", "serial": {"%s": %s}, "password": "%s"}'%(name,parental,url,mac,serialmode,serialvalue,password)
            raw_url = "tmp=%s&genre_name=['%s']&title=%s&cmd=%s&portal=%s&mode=play&logo_url=%s"%(tmp,genre_name,title,cmd,portal_string,logo_url)
            url = addonurl + urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
        except: pass

#        xbmcgui.Dialog().ok(__addonname__, url)
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
#        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);

#        addLink(videoTitle,url,thumbnail)
#        xbmc.executebuiltin("Container.SetSortMethod(7)");
        liz=xbmcgui.ListItem(videoTitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": videoTitle } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'BlackandWhite':
    foldername = args['foldername'][0]
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/oldmovies.php?key='+custom_key)
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URLblackandwhite = f.url
    tmpListFile = os.path.join(TARGETFOLDER, 'tempList.txt')
    playlistFile = MAIN_URLblackandwhite
    tmpList = []
    list = common.m3u2list(playlistFile)

    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
#        liz=xbmcgui.ListItem(name ,channel["url"], 3, "")
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
        url = channel["url"]
#        tmpList.append({"url": channel["url"], "image": "", "name": name.decode("utf-8")})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

    common.SaveList(tmpListFile, tmpList)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))