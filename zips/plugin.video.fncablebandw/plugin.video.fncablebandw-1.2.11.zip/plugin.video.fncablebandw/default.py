# -*- coding: cp1254 -*-
# please visit http://www.iptvxtra.net

mainurl="http://freenetcable.com/live/test/uk-streams.xml"

import sys
import urllib
import urlparse
import base64
import cookielib,sys
import urllib2,urllib,re,os
import json
import hashlib
import pdb
import httplib
import sqlite3
from datetime import tzinfo, timedelta, datetime
import xml.etree.ElementTree as ET
import time
import xbmcplugin,xbmcgui,xbmc,xbmcaddon

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'albums')
Addon = xbmcaddon.Addon('plugin.video.fncablebandw')
addon_id = 'plugin.video.fncablebandw'
selfAddon = xbmcaddon.Addon(id=addon_id)
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
addonsettings = xbmcaddon.Addon(id='plugin.video.fncablebandw')
__language__ = addonsettings.getLocalizedString
home = addonsettings.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
code1 = 'http://nix02.'

TARGETFOLDERaddon = xbmc.translatePath(
'special://home/addons/plugin.video.fncablebandw/'
)


libDir = os.path.join(TARGETFOLDERaddon, 'resources', 'lib')
sys.path.insert(0, libDir)
import common

__addon__ = xbmcaddon.Addon('plugin.video.fncablebandw')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
time = 6000 #in miliseconds

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'Loading Please Wait', time, __icon__))

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
    lineworking = 'Registered'
else:
    xbmcgui.Dialog().ok(__addonname__, 'Please Register your FnCable')
    sys.exit(0)

TARGETFOLDER = xbmc.translatePath(
'special://home/userdata/addon_data/plugin.video.fncablebandw/'
)

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;

#====here is the action
def check_name(Checkname):
    conn = sqlite3.connect(TARGETFOLDER+'Rename.db')
    cursor = conn.cursor()

    cursor.execute('select OriginalName, NewName from Rename')

    for OriginalName, NewName in cursor.fetchall():
        if OriginalName.encode('utf8')==Checkname:
            return NewName.encode('utf8'),'Done'
            
    print 'no matching'
    return '','Failed'
    conn.close()

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def ginico(url):
    x = url.partition('---')
    url = x[0]
    id = x[2].replace('xxx','')
    r = requests.get("http://giniko.com/watch.php?id=" + id)
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=37")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=220")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    else: return url

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/oldmovies.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URLblackandwhite = f.url
    tmpListFile = os.path.join(TARGETFOLDER, 'tempList.txt')
    playlistFile = MAIN_URLblackandwhite
    tmpList = []
    list = common.m3u2list(playlistFile)

    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
#        liz=xbmcgui.ListItem(name ,channel["url"], 3, "")
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
        url = channel["url"]
#        tmpList.append({"url": channel["url"], "image": "", "name": name.decode("utf-8")})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

    common.SaveList(tmpListFile, tmpList)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode[0] == 'BlackandWhite':
    foldername = args['foldername'][0]
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/oldmovies.php?key='+custom_key, headers={ 'User-Agent': 'Mozilla/5.0' })
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URLblackandwhite = f.url
    tmpListFile = os.path.join(TARGETFOLDER, 'tempList.txt')
    playlistFile = MAIN_URLblackandwhite
    tmpList = []
    list = common.m3u2list(playlistFile)

    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
#        liz=xbmcgui.ListItem(name ,channel["url"], 3, "")
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
        url = channel["url"]
#        tmpList.append({"url": channel["url"], "image": "", "name": name.decode("utf-8")})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

    common.SaveList(tmpListFile, tmpList)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))