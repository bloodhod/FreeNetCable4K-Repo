#   script.maintenancetool, Maintenance Tool
#   Copyright (C) 2015  Spencer Kuzara
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.



import urllib,urllib2,re, time
import xbmcgui,xbmcplugin
import os
import os
import xbmc
import xbmcaddon
import zipfile

time = 3000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.fncablehowto')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Loading'

thumbnailPath = xbmc.translatePath('special://thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'script.fncablehowto')
mediaPath = os.path.join(addonPath, 'media')
databasePath = xbmc.translatePath('special://database')

TARGETFOLDER = xbmc.translatePath(
'special://home/images/'
)

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e

#CLASSES

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

#DEFINE MENU

def mainMenu():
    addItem('', 'url', 1,os.path.join(mediaPath, "fncableactivate.png"))
    addItem('', 'url', 20,os.path.join(mediaPath, "fncableaddtofavourites.png"))
    addItem('', 'url', 2,os.path.join(mediaPath, "fncableadujstvideo.png"))
    addItem('', 'url', 3,os.path.join(mediaPath, "fncableallchannels.png"))
    addItem('','url', 18,os.path.join(mediaPath, "fncablechangetimezone.png"))
    addItem('','url', 4,os.path.join(mediaPath, "fncablechangeweather.png"))
    addItem('','url', 5,os.path.join(mediaPath, "fncablecloudupdates.png"))
    addItem('', 'url', 6,os.path.join(mediaPath, "fncableconnecteth.png"))
    addItem('', 'url', 7,os.path.join(mediaPath, "fncableconnectwifi.png"))
    addItem('', 'url', 8,os.path.join(mediaPath, "fncablefixbuffer.png"))
    addItem('', 'url', 9,os.path.join(mediaPath, "fncableguide.png"))
    addItem('', 'url', 23,os.path.join(mediaPath, "fncableinitialsetup.png"))
    addItem('', 'url', 10,os.path.join(mediaPath, "fncablelivesportsevents.png"))
    addItem('', 'url', 19,os.path.join(mediaPath, "fncablemanagefavourites.png"))
    addItem('', 'url', 22,os.path.join(mediaPath, "fncablemediacontrol.png"))
    addItem('', 'url', 11,os.path.join(mediaPath, "fncablemenunavigation.png"))
    addItem('', 'url', 12,os.path.join(mediaPath, "fncablereset.png"))
    addItem('', 'url', 21,os.path.join(mediaPath, "fncablerestart.png"))
    addItem('', 'url', 13,os.path.join(mediaPath, "fncableshutdown.png"))
    addItem('', 'url', 14,os.path.join(mediaPath, "fncablespeedtest.png"))
    addItem('', 'url', 16,os.path.join(mediaPath, "fncablestart.png"))
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
#ADD TO MENU

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("CableOi","Loading Please Wait...")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok


def addDir(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

#PARSES CHOICE
      
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param   

#WORK FUNCTIONS
def setupCacheEntries():
    entries = 5 #make sure this reflects the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries

def FnCableCloudUpdates():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/CloudUpdate.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")
    
def FnCableAllChannels():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/AllChannels.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")
    
def FnCableGuide():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/Guide.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableLiveSportsEvents():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/Sports.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableMenuNavigation():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/Navigate.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableSpeedTest():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/SpeedTest.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableActivate():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/ActivateCableOi.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableShutdown():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/Shutdown.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableStart():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/StartCableOi.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableAdjustVideo():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/VideoAdjust.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableChangeWeather():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/Weather.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableConnectEth():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/ConnectEthernet.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableConnectWiFi():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/ConnectWiFi.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableFixBuffer():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/FixBuffer.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableReset():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/ResetCableOi.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableChangeTimeZone():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/ChangeTimeZone.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableManageFavourites():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/ManageFavorites.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableAddToFavourites():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/AddToFavourite.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableRestart():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/RestartCableOi.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableMediaControl():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/MediaControl.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableInitialSetup():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    dialog = xbmcgui.Dialog()
    entries = ["English", "Spanish"]
    nr = dialog.select("Select Language", entries)
    if nr>=0:
        entry = entries[nr]
    else:
        sys.exit(0)
    if entry == 'English':
        url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/InitialSetupEN.zip'
    elif entry == 'Spanish':
        url ='http://cableoverinternet.com/cableoverinternet.com/nishantha/howto/InitialSetupES.zip'
    downloadepath = TARGETFOLDER+"tempfile.zip"
    DownloaderClass(url,downloadepath)

    zip_ref = zipfile.ZipFile(downloadepath, 'r')
    zip_ref.extractall(TARGETFOLDER)
    zip_ref.close()
    os.remove(downloadepath)

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

#START MAIN           

params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        mainMenu()

elif mode==1:
        FnCableActivate()

elif mode==2:
		FnCableAdjustVideo()
        
elif mode==3:
        FnCableAllChannels()

elif mode==4:
		FnCableChangeWeather()

elif mode==5:
		FnCableCloudUpdates()

elif mode==6:
        FnCableConnectEth()

elif mode==7:
        FnCableConnectWiFi()

elif mode==8:
        FnCableFixBuffer()

elif mode==9:
        FnCableGuide()

elif mode==10:
        FnCableLiveSportsEvents()

elif mode==11:
        FnCableMenuNavigation()

elif mode==12:
        FnCableReset()

elif mode==13:
        FnCableShutdown()

elif mode==14:
        FnCableSpeedTest()

elif mode==16:
        FnCableStart()

elif mode==18:
        FnCableChangeTimeZone()

elif mode==19:
        FnCableManageFavourites()

elif mode==20:
        FnCableAddToFavourites()

elif mode==21:
        FnCableRestart()

elif mode==22:
        FnCableMediaControl()

elif mode==23:
        FnCableInitialSetup()

xbmcplugin.endOfDirectory(int(sys.argv[1]))

