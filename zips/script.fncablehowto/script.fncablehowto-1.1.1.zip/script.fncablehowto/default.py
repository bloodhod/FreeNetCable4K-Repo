#   script.maintenancetool, Maintenance Tool
#   Copyright (C) 2015  Spencer Kuzara
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.



import urllib,urllib2,re, time
import xbmcgui,xbmcplugin
import os
import os
import xbmc
import xbmcaddon

time = 3000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.fncablehowto')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Loading'

thumbnailPath = xbmc.translatePath('special://thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'script.fncablehowto')
mediaPath = os.path.join(addonPath, 'media')
databasePath = xbmc.translatePath('special://database')

TARGETFOLDER = xbmc.translatePath(
'special://home/images/'
)

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e

#CLASSES

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

#DEFINE MENU

def mainMenu():
    xbmc.executebuiltin("Container.SetViewMode(500)")
    addItem('', 'url', 1,os.path.join(mediaPath, "fncableallchannels.png"))
    addItem('','url', 2,os.path.join(mediaPath, "fncablecloudupdates.png"))
    addItem('', 'url', 3,os.path.join(mediaPath, "fncableguide.png"))
    addItem('', 'url', 4,os.path.join(mediaPath, "fncablelivesportsevents.png"))
    addItem('', 'url', 5,os.path.join(mediaPath, "fncablepayperview.png"))
    
#ADD TO MENU

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok


def addDir(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

#PARSES CHOICE
      
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param   

#WORK FUNCTIONS
def setupCacheEntries():
    entries = 5 #make sure this reflects the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries


def FnCableCloudUpdates():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-cloud-updates0.jpg", TARGETFOLDER+"fncable-cloud-updates0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates1.jpg", TARGETFOLDER+"fncable-cloud-updates1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates2.jpg", TARGETFOLDER+"fncable-cloud-updates2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates3.jpg", TARGETFOLDER+"fncable-cloud-updates3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates4.jpg", TARGETFOLDER+"fncable-cloud-updates4.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates5.jpg", TARGETFOLDER+"fncable-cloud-updates5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates6.jpg", TARGETFOLDER+"fncable-cloud-updates6.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates7.jpg", TARGETFOLDER+"fncable-cloud-updates7.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates8.jpg", TARGETFOLDER+"fncable-cloud-updates8.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates9.jpg", TARGETFOLDER+"fncable-cloud-updates9.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates10.jpg", TARGETFOLDER+"fncable-cloud-updates10.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates11.jpg", TARGETFOLDER+"fncable-cloud-updates11.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates12.jpg", TARGETFOLDER+"fncable-cloud-updates12.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates13.jpg", TARGETFOLDER+"fncable-cloud-updates13.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates14.jpg", TARGETFOLDER+"fncable-cloud-updates14.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates15.jpg", TARGETFOLDER+"fncable-cloud-updates15.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates16.jpg", TARGETFOLDER+"fncable-cloud-updates16.jpg")


    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")
    
def FnCableAllChannels():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-all-channels0.jpg", TARGETFOLDER+"fncable-all-channels0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-all-channels1.jpg", TARGETFOLDER+"fncable-all-channels1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-all-channels2.jpg", TARGETFOLDER+"fncable-all-channels2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-all-channels3.jpg", TARGETFOLDER+"fncable-all-channels3.jpg")

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")
    
def FnCableGuide():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-guide0.jpg", TARGETFOLDER+"fncable-guide0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide1.jpg", TARGETFOLDER+"fncable-guide1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide2.jpg", TARGETFOLDER+"fncable-guide2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide3.jpg", TARGETFOLDER+"fncable-guide3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide4.jpg", TARGETFOLDER+"fncable-guide4.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide5.jpg", TARGETFOLDER+"fncable-guide5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide6.jpg", TARGETFOLDER+"fncable-guide6.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide7.jpg", TARGETFOLDER+"fncable-guide7.jpg")

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableLiveSportsEvents():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-live-sports-events0.jpg", TARGETFOLDER+"fncable-live-sports-events0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-live-sports-events1.jpg", TARGETFOLDER+"fncable-live-sports-events1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-live-sports-events2.jpg", TARGETFOLDER+"fncable-live-sports-events2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-live-sports-events3.jpg", TARGETFOLDER+"fncable-live-sports-events3.jpg")

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCablePayPerView():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-sports-pay-per-view0.jpg", TARGETFOLDER+"fncable-sports-pay-per-view0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-sports-pay-per-view1.jpg", TARGETFOLDER+"fncable-sports-pay-per-view1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-sports-pay-per-view2.jpg", TARGETFOLDER+"fncable-sports-pay-per-view2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-sports-pay-per-view3.jpg", TARGETFOLDER+"fncable-sports-pay-per-view3.jpg")

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")


#START MAIN           

params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        mainMenu()
       
elif mode==1:
		FnCableAllChannels()
        
elif mode==2:
        FnCableCloudUpdates()

elif mode==3:
		FnCableGuide()

elif mode==4:
		FnCableLiveSportsEvents()

elif mode==5:
        FnCablePayPerView()
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))

