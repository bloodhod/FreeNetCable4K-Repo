#   script.maintenancetool, Maintenance Tool
#   Copyright (C) 2015  Spencer Kuzara
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.



import urllib,urllib2,re, time
import xbmcgui,xbmcplugin
import os
import os
import xbmc
import xbmcaddon

time = 3000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.fncablehowto')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Loading'

thumbnailPath = xbmc.translatePath('special://thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'script.fncablehowto')
mediaPath = os.path.join(addonPath, 'media')
databasePath = xbmc.translatePath('special://database')

TARGETFOLDER = xbmc.translatePath(
'special://home/images/'
)

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e

#CLASSES

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

#DEFINE MENU

def mainMenu():
    xbmc.executebuiltin("Container.SetViewMode(500)")
    addItem('', 'url', 1,os.path.join(mediaPath, "fncableactivate.png"))
    addItem('', 'url', 2,os.path.join(mediaPath, "fncableadujstvideo.png"))
    addItem('', 'url', 3,os.path.join(mediaPath, "fncableallchannels.png"))
    addItem('','url', 4,os.path.join(mediaPath, "fncablechangeweather.png"))
    addItem('','url', 5,os.path.join(mediaPath, "fncablecloudupdates.png"))
    addItem('', 'url', 6,os.path.join(mediaPath, "fncableconnecteth.png"))
    addItem('', 'url', 7,os.path.join(mediaPath, "fncableconnectwifi.png"))
    addItem('', 'url', 8,os.path.join(mediaPath, "fncablefixbuffer.png"))
    addItem('', 'url', 9,os.path.join(mediaPath, "fncableguide.png"))
    addItem('', 'url', 10,os.path.join(mediaPath, "fncablelivesportsevents.png"))
    addItem('', 'url', 11,os.path.join(mediaPath, "fncablemenunavigation.png"))
    addItem('', 'url', 12,os.path.join(mediaPath, "fncablereset.png"))
    addItem('', 'url', 13,os.path.join(mediaPath, "fncableshutdown.png"))
    addItem('', 'url', 14,os.path.join(mediaPath, "fncablespeedtest.png"))
    addItem('', 'url', 15,os.path.join(mediaPath, "fncablepayperview.png"))
    addItem('', 'url', 16,os.path.join(mediaPath, "fncablestart.png"))
    addItem('', 'url', 17,os.path.join(mediaPath, "fncableswipfix.png"))
    
#ADD TO MENU

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok


def addDir(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

#PARSES CHOICE
      
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param   

#WORK FUNCTIONS
def setupCacheEntries():
    entries = 5 #make sure this reflects the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries

def FnCableCloudUpdates():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Cloud Updates')
    pDialog.update(10, 'Loading Cloud Updates')
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-cloud-updates0.jpg", TARGETFOLDER+"fncable-cloud-updates0.jpg")
    pDialog.update(15, 'Loading Cloud Updates')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates1.jpg", TARGETFOLDER+"fncable-cloud-updates1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates2.jpg", TARGETFOLDER+"fncable-cloud-updates2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates3.jpg", TARGETFOLDER+"fncable-cloud-updates3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates4.jpg", TARGETFOLDER+"fncable-cloud-updates4.jpg")
    pDialog.update(40, 'Loading Cloud Updates')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates5.jpg", TARGETFOLDER+"fncable-cloud-updates5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates6.jpg", TARGETFOLDER+"fncable-cloud-updates6.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates7.jpg", TARGETFOLDER+"fncable-cloud-updates7.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates8.jpg", TARGETFOLDER+"fncable-cloud-updates8.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates9.jpg", TARGETFOLDER+"fncable-cloud-updates9.jpg")
    pDialog.update(50, 'Loading Cloud Updates')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates10.jpg", TARGETFOLDER+"fncable-cloud-updates10.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates11.jpg", TARGETFOLDER+"fncable-cloud-updates11.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates12.jpg", TARGETFOLDER+"fncable-cloud-updates12.jpg")
    pDialog.update(75, 'Loading Cloud Updates')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates13.jpg", TARGETFOLDER+"fncable-cloud-updates13.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates14.jpg", TARGETFOLDER+"fncable-cloud-updates14.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates15.jpg", TARGETFOLDER+"fncable-cloud-updates15.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates16.jpg", TARGETFOLDER+"fncable-cloud-updates16.jpg")
    pDialog.update(100, 'Starting Cloud Updates')
    pDialog.close()


    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")
    
def FnCableAllChannels():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading All Channels')
    pDialog.update(25, 'Loading All Channels')
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-all-channels0.jpg", TARGETFOLDER+"fncable-all-channels0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-all-channels1.jpg", TARGETFOLDER+"fncable-all-channels1.jpg")
    pDialog.update(50, 'Loading All Channels')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-all-channels2.jpg", TARGETFOLDER+"fncable-all-channels2.jpg")
    pDialog.update(75, 'Loading All Channels')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-all-channels3.jpg", TARGETFOLDER+"fncable-all-channels3.jpg")
    pDialog.update(100, 'Starting All Channels')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")
    
def FnCableGuide():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Guide')
    pDialog.update(25, 'Loading Guide')
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-guide0.jpg", TARGETFOLDER+"fncable-guide0.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide1.jpg", TARGETFOLDER+"fncable-guide1.jpg")
    pDialog.update(40, 'Loading Guide')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide2.jpg", TARGETFOLDER+"fncable-guide2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide3.jpg", TARGETFOLDER+"fncable-guide3.jpg")
    pDialog.update(50, 'Loading Guide')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide4.jpg", TARGETFOLDER+"fncable-guide4.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide5.jpg", TARGETFOLDER+"fncable-guide5.jpg")
    pDialog.update(75, 'Loading Guide')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide6.jpg", TARGETFOLDER+"fncable-guide6.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-guide7.jpg", TARGETFOLDER+"fncable-guide7.jpg")
    pDialog.update(100, 'Starting Guide')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableLiveSportsEvents():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Live Sports Events')
    pDialog.update(25, 'Loading Live Sports Events')
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-live-sports-events0.jpg", TARGETFOLDER+"fncable-live-sports-events0.jpg")
    pDialog.update(50, 'Loading Live Sports Events')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-live-sports-events1.jpg", TARGETFOLDER+"fncable-live-sports-events1.jpg")
    pDialog.update(75, 'Loading Live Sports Events')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-live-sports-events2.jpg", TARGETFOLDER+"fncable-live-sports-events2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-live-sports-events3.jpg", TARGETFOLDER+"fncable-live-sports-events3.jpg")
    pDialog.update(100, 'Starting Live Sports Events')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCablePayPerView():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Sports Pay Per View')
    pDialog.update(25, 'Loading Sports Pay Per View')
    urllib.urlretrieve ("http://freenetcable.com/live/test/Howto/fncable-sports-pay-per-view0.jpg", TARGETFOLDER+"fncable-sports-pay-per-view0.jpg")
    pDialog.update(50, 'Loading Sports Pay Per View')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-sports-pay-per-view1.jpg", TARGETFOLDER+"fncable-sports-pay-per-view1.jpg")
    pDialog.update(75, 'Loading Sports Pay Per View')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-sports-pay-per-view2.jpg", TARGETFOLDER+"fncable-sports-pay-per-view2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-sports-pay-per-view3.jpg", TARGETFOLDER+"fncable-sports-pay-per-view3.jpg")
    pDialog.update(100, 'Starting Sports Pay Per View')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableMenuNavigation():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Menu Navigation')
    pDialog.update(25, 'Loading Menu Navigation')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-how-to-menu-navigation.jpg", TARGETFOLDER+"fncable-how-to-menu-navigation.jpg")
    pDialog.update(50, 'Loading Menu Navigation')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-Menu-Navigation1.jpg", TARGETFOLDER+"FnCable-How-To-Menu-Navigation1.jpg")
    pDialog.update(100, 'Starting Menu Navigation')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableSpeedTest():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Speed Test')
    pDialog.update(25, 'Loading Speed Test')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Speedtest.jpg", TARGETFOLDER+"FnCable-Speedtest.jpg")
    pDialog.update(50, 'Loading Speed Test')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Speedtest1.jpg", TARGETFOLDER+"FnCable-Speedtest1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Speedtest2.jpg", TARGETFOLDER+"FnCable-Speedtest2.jpg")
    pDialog.update(75, 'Loading Speed Test')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Speedtest3.jpg", TARGETFOLDER+"FnCable-Speedtest3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Speedtest4.jpg", TARGETFOLDER+"FnCable-Speedtest4.jpg")
    pDialog.update(100, 'Starting Speed Test')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableSwipFix():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Swipe down from top fix')
    pDialog.update(25, 'Loading Swipe down from top fix')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-swipe-down-from-top-fix.jpg", TARGETFOLDER+"FnCable-swipe-down-from-top-fix.jpg")
    pDialog.update(50, 'Loading Swipe down from top fix')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-swipe-down-from-top-fix1.jpg", TARGETFOLDER+"FnCable-swipe-down-from-top-fix1.jpg")
    pDialog.update(100, 'Starting Swipe down from top fix')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableActivate():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Activate FnCable')
    pDialog.update(25, 'Loading Activate FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-Activate-Fncable.jpg", TARGETFOLDER+"FnCable-Activate-Fncable.jpg")
    pDialog.update(40, 'Loading Activate FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates12.jpg", TARGETFOLDER+"FnCable-Activate-Fncable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates13.jpg", TARGETFOLDER+"FnCable-Activate-Fncable2.jpg")
    pDialog.update(50, 'Loading Activate FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates14.jpg", TARGETFOLDER+"FnCable-Activate-Fncable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Activate-Fncable1.jpg", TARGETFOLDER+"FnCable-Activate-Fncable4.jpg")
    pDialog.update(75, 'Loading Activate FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Activate-Fncable2.jpg", TARGETFOLDER+"FnCable-Activate-Fncable5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Activate-Fncable3.jpg", TARGETFOLDER+"FnCable-Activate-Fncable6.jpg")
    pDialog.update(100, 'Starting Activate FnCable')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableShutdown():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Shutdown')
    pDialog.update(25, 'Loading Shutdown')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown.jpg", TARGETFOLDER+"FnCable-How-To-FnCable-Shutdown.jpg")
    pDialog.update(50, 'Loading Shutdown') 
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown1.jpg", TARGETFOLDER+"FnCable-How-To-FnCable-Shutdown1.jpg")
    pDialog.update(75, 'Loading Shutdown')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown2.jpg", TARGETFOLDER+"FnCable-How-To-FnCable-Shutdown2.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown3.jpg", TARGETFOLDER+"FnCable-How-To-FnCable-Shutdown3.jpg")
    pDialog.update(100, 'Starting Shutdown')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableStart():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Start FnCable')
    pDialog.update(25, 'Loading Start FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Start-Fncable.jpg", TARGETFOLDER+"FnCable-Start-Fncable.jpg")
    pDialog.update(40, 'Loading Start FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates1.jpg", TARGETFOLDER+"FnCable-Start-Fncable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates9.jpg", TARGETFOLDER+"FnCable-Start-Fncable2.jpg")
    pDialog.update(50, 'Loading Start FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates10.jpg", TARGETFOLDER+"FnCable-Start-Fncable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates11.jpg", TARGETFOLDER+"FnCable-Start-Fncable4.jpg")
    pDialog.update(70, 'Loading Start FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Start-Fncable1.jpg", TARGETFOLDER+"FnCable-Start-Fncable5.jpg")
    pDialog.update(100, 'Starting Start FnCable')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableAdjustVideo():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Start FnCable')
    pDialog.update(25, 'Loading Adjust Video Position')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-adjust-video-position.jpg", TARGETFOLDER+"FnCable.jpg")
    pDialog.update(40, 'Loading Adjust Video Position')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown1.jpg", TARGETFOLDER+"FnCable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-adjust-video-position1.jpg", TARGETFOLDER+"FnCable2.jpg")
    pDialog.update(50, 'Loading Adjust Video Position')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-adjust-video-position2.jpg", TARGETFOLDER+"FnCable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-adjust-video-position3.jpg", TARGETFOLDER+"FnCable4.jpg")
    pDialog.update(70, 'Loading Adjust Video Position')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-adjust-video-position4.jpg", TARGETFOLDER+"FnCable5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-adjust-video-position5.jpg", TARGETFOLDER+"FnCable6.jpg")
    pDialog.update(100, 'Starting Adjust Video Position')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableChangeWeather():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Change Weather Location')
    pDialog.update(25, 'Loading Change Weather Location')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location.jpg", TARGETFOLDER+"FnCable.jpg")
    pDialog.update(40, 'Loading Change Weather Location')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown1.jpg", TARGETFOLDER+"FnCable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location1.jpg", TARGETFOLDER+"FnCable2.jpg")
    pDialog.update(50, 'Loading Change Weather Location')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location2.jpg", TARGETFOLDER+"FnCable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location3.jpg", TARGETFOLDER+"FnCable4.jpg")
    pDialog.update(70, 'Loading Change Weather Location')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location4.jpg", TARGETFOLDER+"FnCable5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location5.jpg", TARGETFOLDER+"FnCable6.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/FnCable-How-To-FnCable-Shutdown1.jpg", TARGETFOLDER+"FnCable7.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-How-To-FnCable-Shutdown2.jpg", TARGETFOLDER+"FnCable8.jpg")
    pDialog.update(85, 'Loading Change Weather Location')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-reset-fncable4.jpg", TARGETFOLDER+"FnCable9.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates10.jpg", TARGETFOLDER+"FnCable10.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-change-weather-location6.jpg", TARGETFOLDER+"FnCable11.jpg")
    pDialog.update(100, 'Starting Change Weather Location')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableConnectEth():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Connect Ethernet')
    pDialog.update(25, 'Loading Connect Ethernet')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-ethernet.jpg", TARGETFOLDER+"FnCable.jpg")
    pDialog.update(50, 'Loading Connect Ethernet')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-ethernet1.jpg", TARGETFOLDER+"FnCable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-ethernet2.jpg", TARGETFOLDER+"FnCable2.jpg")
    pDialog.update(100, 'Starting Connect Ethernet')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableConnectWiFi():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Connect Wifi')
    pDialog.update(25, 'Loading Connect Wifi')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-wifi.jpg", TARGETFOLDER+"FnCable.jpg")
    pDialog.update(40, 'Loading Connect Wifi')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-ethernet1.jpg", TARGETFOLDER+"FnCable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-wifi1.jpg", TARGETFOLDER+"FnCable2.jpg")
    pDialog.update(65, 'Loading Connect Wifi')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-wifi2.jpg", TARGETFOLDER+"FnCable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-connect-wifi3.jpg", TARGETFOLDER+"FnCable4.jpg")
    pDialog.update(100, 'Starting Connect Wifi')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableFixBuffer():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Fix Buffering')
    pDialog.update(25, 'Loading Fix Buffering')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-fix-buffering.jpg", TARGETFOLDER+"FnCable.jpg")
    pDialog.update(40, 'Loading Fix Buffering')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-fix-buffering1.jpg", TARGETFOLDER+"FnCable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-fix-buffering2.jpg", TARGETFOLDER+"FnCable2.jpg")
    pDialog.update(50, 'Loading Fix Buffering')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-fix-buffering3.jpg", TARGETFOLDER+"FnCable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-fix-buffering4.jpg", TARGETFOLDER+"FnCable4.jpg")
    pDialog.update(70, 'Loading Fix Buffering')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-fix-buffering5.jpg", TARGETFOLDER+"FnCable5.jpg")
    pDialog.update(100, 'Starting Fix Buffering')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")

def FnCableReset():
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('FnCable', 'Loading Reset FnCable')
    pDialog.update(25, 'Loading Reset FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-reset-fncable.jpg", TARGETFOLDER+"FnCable.jpg")
    pDialog.update(40, 'Loading Reset FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates12.jpg", TARGETFOLDER+"FnCable1.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-reset-fncable1.jpg", TARGETFOLDER+"FnCable2.jpg")
    pDialog.update(50, 'Loading Reset FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-reset-fncable2.jpg", TARGETFOLDER+"FnCable3.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-reset-fncable3.jpg", TARGETFOLDER+"FnCable4.jpg")
    pDialog.update(70, 'Loading Reset FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates12.jpg", TARGETFOLDER+"FnCable5.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-How-To-FnCable-Shutdown2.jpg", TARGETFOLDER+"FnCable6.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-reset-fncable4.jpg", TARGETFOLDER+"FnCable7.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates10.jpg", TARGETFOLDER+"FnCable8.jpg")
    pDialog.update(80, 'Loading Reset FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates11.jpg", TARGETFOLDER+"FnCable9.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates12.jpg", TARGETFOLDER+"FnCable10.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/10/fncable-cloud-updates13.jpg", TARGETFOLDER+"FnCable11.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/fncable-cloud-updates141.jpg", TARGETFOLDER+"FnCable12.jpg")
    pDialog.update(88, 'Loading Reset FnCable')
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Activate-Fncable11.jpg", TARGETFOLDER+"FnCable13.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Activate-Fncable21.jpg", TARGETFOLDER+"FnCable14.jpg")
    urllib.urlretrieve ("http://freenetcable.com/wp-content/uploads/2015/12/FnCable-Activate-Fncable31.jpg", TARGETFOLDER+"FnCable15.jpg")
    pDialog.update(100, 'Starting Reset FnCable')
    pDialog.close()

    xbmc.executebuiltin("SlideShow(special://home/images/,notrecursive,notrandom)")


#START MAIN           

params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        mainMenu()

elif mode==1:
        FnCableActivate()

elif mode==2:
		FnCableAdjustVideo()
        
elif mode==3:
        FnCableAllChannels()

elif mode==4:
		FnCableChangeWeather()

elif mode==5:
		FnCableCloudUpdates()

elif mode==6:
        FnCableConnectEth()

elif mode==7:
        FnCableConnectWiFi()

elif mode==8:
        FnCableFixBuffer()

elif mode==9:
        FnCableGuide()

elif mode==10:
        FnCableLiveSportsEvents()

elif mode==11:
        FnCableMenuNavigation()

elif mode==12:
        FnCableReset()

elif mode==13:
        FnCableShutdown()

elif mode==14:
        FnCableSpeedTest()

elif mode==15:
        FnCablePayPerView()

elif mode==16:
        FnCableStart()

elif mode==17:
        FnCableSwipFix()
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))

