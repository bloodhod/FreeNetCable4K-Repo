import sqlite3,re,pdb
import xbmc
import xbmcgui
import xbmcaddon

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/addon_data/script.ftvguide4K/'
    )

# get channels from addons.ini
pattern = re.compile(r'^([a-zA-Z1-9]+)\=plugin\:',re.I)
with open(TARGETFOLDER+'addons.ini','r') as f:
    data = f.read().split('\n')
channels = filter(lambda x: bool(x),[pattern.findall(i) for i in data])

##pdb.set_trace()





# sql reset to 0 all channels
conn = sqlite3.connect(TARGETFOLDER+'source.db')
curs = conn.cursor()
sql='update channels set visible=0'
curs.execute(sql)
conn.commit()
# sql set to 1 channels from addons
conn = sqlite3.connect(TARGETFOLDER+'source.db')
curs = conn.cursor()
for item in channels:
    print 'updating visibility for channel %s'%item[0]
    sql='update channels set visible=1 where title="%s"'%item[0]
    curs.execute(sql)
conn.commit()


# close db
conn.close()
print 'job done'
