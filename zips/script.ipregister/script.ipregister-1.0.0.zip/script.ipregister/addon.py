import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import urllib2,json,sys
import shutil

__addon__ = xbmcaddon.Addon('script.ipregister')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Please Wait'
line2 = 'Failed'
time = 2000 #in miliseconds
custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

xbmcaddon.Addon().openSettings()

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/Database'
    )

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__, line1, time, __icon__))

url = "http://freenetcable.com/live/test/reg.php?key="+custom_key
print 'getting url...'
try:
    dic = json.loads(urllib2.urlopen(url).read())
    if dic['data'].has_key('registered_ip'):
        response_line1 = 'Successfully registered '+dic['data']['key']
    elif dic['data'].has_key('message'):
        response_line1 = dic['data']['message']
    response_line2 = dic['data']['status']
    print response_line1
    print response_line2
except Exception as er:
    print str(er)
    print 'the data from the given url address is not json encoded'

xbmcgui.Dialog().ok(__addonname__, response_line1)
#xbmcgui.Dialog().ok(__addonname__, line1, line2)