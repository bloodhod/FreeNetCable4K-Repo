import xbmcaddon
import xbmcgui
import json, xml, pdb, os
from xml.dom import minidom
import sqlite3
import shutil

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
 
line1 = 'You have successfully added '+custom_key
line2 = "Enjoy!!!"

xbmcaddon.Addon().openSettings()
#xbmc.executebuiltin("RunAddon(plugin.video.fncablelocal)")
#xbmcgui.Dialog().ok(__addonname__, line1, line2)

ManageGuideFolder = xbmc.translatePath(
    'special://home/userdata/addon_data/script.manageguide/'
    )

TARGETFOLDER = xbmc.translatePath(
    '/sdcard/'
    )

try:
    if os.path.exists(ManageGuideFolder+'settings.xml') and not os.path.exists(ManageGuideFolder+'settings.db'):
        conn = sqlite3.connect(ManageGuideFolder+'settings.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE Channels
                 (ChannelID text UNIQUE, Visibility text)''')
        conn.commit()
        xml_filename = ManageGuideFolder+"settings.xml"
        xmldoc = minidom.parse(xml_filename)
        reflist = xmldoc.getElementsByTagName('setting')
        for aux_xml in reflist:
            findid = aux_xml.attributes["id"].value
            findvalue = aux_xml.attributes["value"].value
            c.execute("INSERT INTO Channels VALUES (?, ?)", (findid,findvalue))
        conn.commit()
except:
    pass

try:
    if os.path.exists(ManageGuideFolder+'settings.xml') and os.path.exists(ManageGuideFolder+'settings.db'):
        conn = sqlite3.connect(ManageGuideFolder+'settings.db')
        c = conn.cursor()
        xml_filename = ManageGuideFolder+"settings.xml"
        xmldoc = minidom.parse(xml_filename)
        reflist = xmldoc.getElementsByTagName('setting')
        for aux_xml in reflist:
            findid = aux_xml.attributes["id"].value
            findvalue = aux_xml.attributes["value"].value
            c.execute ("UPDATE Channels SET Visibility=? WHERE ChannelID=? ", (findvalue, findid))
        conn.commit()
except:
    pass

try:
    conn.close()
except:
    pass

try:
    if os.path.exists(ManageGuideFolder+'settings.xml'):
        shutil.copy2(ManageGuideFolder+'settings.xml', TARGETFOLDER+'guidesettings.xml')
except:
    pass

try:
    if os.path.exists(ManageGuideFolder+'settings.db'):
        shutil.copy2(ManageGuideFolder+'settings.db', TARGETFOLDER+'guidesettings.db')
except:
    pass