#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#
#      Modified for tecbox Guide (02/2015 onwards)
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#

import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import urllib2,sys
import httplib
import urllib, json

__addon__ = xbmcaddon.Addon('script.ipregister')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

time = 3000 #in miliseconds

messagetext = 'http://idragonlk.com/CableOiOrderHD.txt'

import xml
from xml.dom import minidom

def open_url2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'DK')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def popup():
            message=open_url2(messagetext)
            showText('[B][COLOR darkorange]HD SPORTS & 1080P PPV[/COLOR][/B]', message)

def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return
        except:
            pass

def activateit(custom_mac,responseObject):
	TARGETFOLDER = xbmc.translatePath(
		'special://home/userdata/addon_data/plugin.video.cableoiiptv/'
		)
	xml_filename = TARGETFOLDER+"settings.xml"
	xmldoc = minidom.parse(xml_filename)
	def change_value(setting_id, new_value):
		reflist = xmldoc.getElementsByTagName('setting')
		for aux_xml in reflist:
			if aux_xml.attributes["id"].value == setting_id:
				if not aux_xml.attributes["value"].value == new_value:
					aux_xml.attributes["value"].value = new_value
	if responseObject["data"]["status"] == True:
		if responseObject["data"]["usertype"] == 'paid':
			for aux_key, aux_value in responseObject["data"].items():
				if aux_key == "password":
					change_value("Password", aux_value)
				if aux_key == "username":
					change_value("Username", aux_value)
			file_handle = open(xml_filename,"wb")
			xmldoc.writexml(file_handle)
			file_handle.close()

def runrest():
	try:
		getethmac = open('/sys/class/net/eth0/address').read()
		custom_key1 = getethmac.replace(':','')
		custom_mac = custom_key1[:12]
	except:
		custom_mac = ''
		pass
	defPassword = urllib2.urlopen("http://www.idragonlk.com/playklubp.txt").read()
	defUsername = urllib2.urlopen("http://www.idragonlk.com/playklubu.txt").read()
	playersUsername = xbmcaddon.Addon('plugin.video.cableoiiptv').getSetting("Username")
	playersPassword = xbmcaddon.Addon('plugin.video.cableoiiptv').getSetting("Password")
	custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
	url = 'http://freenetcable.com/rest/iptv_hd.php?username='+custom_mac+'&key='+custom_key
	responseText = urllib.urlopen(url).read()
	responseObject = json.loads(responseText)
	if responseObject["data"]["status"] == True:
		if responseObject["data"]["usertype"] == 'paid':
			if responseObject["data"]["username"] == defUsername or responseObject["data"]["password"] == defPassword:
				xbmcgui.Dialog().ok('', "Your HD SPORTS & 1080P PPV Subscription Not Activated Yet.")
				sys.exit(0)
			elif responseObject["data"]["username"] == playersUsername and responseObject["data"]["password"] == playersPassword:
#				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('', 'Activating HD SPORTS PPV', time, __icon__))
#				activateit(custom_mac, responseObject)
				yesdone = ''
#				xbmc.executebuiltin('RunAddon(plugin.video.cableoiiptv)')
			elif not responseObject["data"]["username"] == playersUsername or not responseObject["data"]["password"] == playersPassword:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('', 'Activating HD SPORTS & 1080P PPV', time, __icon__))
				activateit(custom_mac, responseObject)
				yesdone = ''
			else:
				xbmcgui.Dialog().ok('', "Looking for More Premium Sports including PPV? So why are you waiting for. Order now.", "13 NHL Center Ice Channels/13 NFL Sunday Tickets Channels/15 NBA League Pass Channels/30 MLB Extra Innings Channels/UFC PPV/WWE PPV", "Over 500 Channels & VOD with Latest Movies & Catch Up. Enjoy Every Sport, Every PPV and Everything!")
				kb = xbmc.Keyboard('', 'Enter your email address')
				kb.doModal()
				if kb.isConfirmed():
					emailaddress = kb.getText()
				else:
					xbmcgui.Dialog().ok('', "Please enter your email address")
					sys.exit(0)

				if not '@' in emailaddress:
					xbmcgui.Dialog().ok('', "Please enter correct email address")
					sys.exit(0)


				kb = xbmc.Keyboard('', 'Enter your name')
				kb.doModal()
				if kb.isConfirmed():
					username = kb.getText()
				else:
					username = custom_key

				url = 'http://freenetcable.com/nishanthalive/phpmailer/sendmailV2.php'
				values = {'email': emailaddress, 'username': username, 'mac': custom_mac, 'key': custom_key}

				headers = { 'User-Agent' : 'Mozilla/5.0' }
				values = urllib.urlencode(values)

				#   req = urllib2.Request(url, values, headers={ 'User-Agent': 'Mozilla/5.0' })
				req = urllib2.Request(url, values)
				html = urllib2.urlopen(req).read()

				#   html = urllib.urlopen(url, urllib.urlencode(values)).read()

				if 'Message could not be sent.' in html:
					xbmcgui.Dialog().ok('', 'Email not sent. Plz try again.')
				elif 'Message has been sent' in html:
					xbmcgui.Dialog().ok('', 'Details Sent. Please check your email. Thanks.')
		elif responseObject["data"]["usertype"] == 'free':
			if not responseObject["data"]["username"] == defUsername or not responseObject["data"]["password"] == defPassword:
				xbmcgui.Dialog().ok('', "Your HD SPORTS & 1080P PPV Subscription Expired. Please Renew")
				sys.exit(0)
			else:
				xbmcgui.Dialog().ok('', "Looking for More Premium Sports including PPV? So why are you waiting for. Order now.", "13 NHL Center Ice Channels/13 NFL Sunday Tickets Channels/15 NBA League Pass Channels/30 MLB Extra Innings Channels/UFC PPV/WWE PPV", "Over 500 Channels & VOD with Latest Movies & Catch Up. Enjoy Every Sport, Every PPV and Everything!")
				kb = xbmc.Keyboard('', 'Enter your email address')
				kb.doModal()
				if kb.isConfirmed():
					emailaddress = kb.getText()
				else:
					xbmcgui.Dialog().ok('', "Please enter your email address")
					sys.exit(0)

				if not '@' in emailaddress:
					xbmcgui.Dialog().ok('', "Please enter correct email address")
					sys.exit(0)


				kb = xbmc.Keyboard('', 'Enter your name')
				kb.doModal()
				if kb.isConfirmed():
					username = kb.getText()
				else:
					username = custom_key

				url = 'http://freenetcable.com/nishanthalive/phpmailer/sendmailV2.php'
				values = {'email': emailaddress, 'username': username, 'mac': custom_mac, 'key': custom_key}

				headers = { 'User-Agent' : 'Mozilla/5.0' }
				values = urllib.urlencode(values)

				#   req = urllib2.Request(url, values, headers={ 'User-Agent': 'Mozilla/5.0' })
				req = urllib2.Request(url, values)
				html = urllib2.urlopen(req).read()

				#   html = urllib.urlopen(url, urllib.urlencode(values)).read()

				if 'Message could not be sent.' in html:
					xbmcgui.Dialog().ok('', 'Email not sent. Plz try again.')
				elif 'Message has been sent' in html:
					xbmcgui.Dialog().ok('', 'Details Sent. Please check your email. Thanks.')