# -*- coding: utf-8 -*-
#
# CableOi Guide Mix
# Copyright (C) 2015 Thomas Geppert [bluezed]
# bluezed.apps@gmail.com
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import os,re,urllib
import urllib2
import datetime
import zlib
import xbmcaddon, xbmcgui
import urllib2, httplib
import zipfile

__addon__ = xbmcaddon.Addon('script.ftvguide4KMix')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/ftvtemp4kmix.php?key='+custom_key)
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/addon_data/script.ftvguide4KMix/'
    )
#MAIN_URL = 'http://freenetcable.com/live/test/ftv.php?key='+custom_key

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgressBG()
    dp.create("CableOi Guide","Downloading Guide Data")
    try:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
        percent = 100
        dp.update(percent)
        dp.close()
        donevalue = 'Done'
    except:
        donevalue = 'Failed'
        percent = 100
        dp.update(percent)
        dp.close()
    percent = 100
    dp.update(percent)
    dp.close()
    return donevalue
     
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
#    if dp.iscanceled(): 
#        print "DOWNLOAD CANCELLED" # need to get this part working
#        dp.close()
    if percent == 100:
        dp.close()

class FileFetcher(object):
    INTERVAL_ALWAYS = 0
    INTERVAL_12 = 1
    INTERVAL_24 = 2
    INTERVAL_48 = 3
    INTERVAL_72 = 4
    INTERVAL_168 = 5

    FETCH_ERROR = -1
    FETCH_NOT_NEEDED = 0
    FETCH_OK = 1

    TYPE_DEFAULT = 1
    TYPE_REMOTE = 2

    basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.ftvguide4KMix'))
    filePath = ''
    fileUrl = ''
    addon = None
    fileType = TYPE_DEFAULT

    def __init__(self, fileName, addon):
        self.addon = addon

        if fileName.startswith("http://") or fileName.startswith("sftp://") or fileName.startswith("ftp://") or \
                fileName.startswith("https://") or fileName.startswith("ftps://") or fileName.startswith("smb://") or \
                fileName.startswith("nfs://"):
            self.fileType = self.TYPE_REMOTE
            self.fileUrl = fileName
            self.filePath = os.path.join(self.basePath, fileName.split('/')[-1])
        else:
            self.fileType = self.TYPE_DEFAULT
            self.fileUrl = MAIN_URL + fileName
            self.filePath = os.path.join(self.basePath, fileName)

        # make sure the folder is actually there already!
        if not os.path.exists(self.basePath):
            os.makedirs(self.basePath)

    def fetchFile(self):
        retVal = self.FETCH_NOT_NEEDED
        fetch = False
        if not os.path.exists(self.filePath):  # always fetch if file doesn't exist!
            fetch = True
        else:
            interval = int(self.addon.getSetting('xmltv.interval'))
            if interval != self.INTERVAL_ALWAYS:
                modTime = datetime.datetime.fromtimestamp(os.path.getmtime(self.filePath))
                td = datetime.datetime.now() - modTime
                # need to do it this way cause Android doesn't support .total_seconds() :(
                diff = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6
                if ((interval == self.INTERVAL_12 and diff >= 43200) or
                        (interval == self.INTERVAL_24 and diff >= 86400) or
                        (interval == self.INTERVAL_48 and diff >= 172800) or
                        (interval == self.INTERVAL_72 and diff >= 259200) or
                        (interval == self.INTERVAL_168 and diff >= 604800)):
                    fetch = True
            else:
                fetch = True

        if fetch:
            if 'guide.xmltv' in self.filePath:
                try:
                    downloadepath = self.filePath+'.zip'
                    iscompleted = DownloaderClass('http://idragonlk.com/GuideXML/guidezip/guide.xmltv.zip',downloadepath)
    #            tmpFile = os.path.join(self.basePath, 'tmp')
    #            f = open(tmpFile, 'wb')
    #            tmpData = urllib2.urlopen(self.fileUrl)
    #            data = tmpData.read()
    #            if tmpData.info().get('content-encoding') == 'gzip':
    #                data = zlib.decompress(data, zlib.MAX_WBITS + 16)
    #            f.write(data)
    #            f.close()
                    if iscompleted == 'Done':
                        try:
                            zip_ref = zipfile.ZipFile(downloadepath, 'r')
                            zip_ref.extractall(TARGETFOLDER)
                            zip_ref.close()
                            os.remove(downloadepath)
                            unzipvalue = 'Done'
                        except:
                            unzipvalue = 'Failed'
                        if unzipvalue == 'Done':
                            if os.path.exists(self.filePath):
                                os.remove(self.filePath)
                            os.rename(TARGETFOLDER+'epg_xmltv.xml', self.filePath)  
                        else:
                            retVal = self.FETCH_ERROR
    #            if os.path.getsize(tmpFile) > 256:
    #                if os.path.exists(self.filePath):
    #                    os.remove(self.filePath)
    #                os.rename(tmpFile, self.filePath)
                        retVal = self.FETCH_OK
                        xbmc.log('[script.ftvguide4KMix] file %s was downloaded' % self.filePath, xbmc.LOGDEBUG)
                    elif iscompleted == 'Failed':
                        retVal = self.FETCH_ERROR
                except:
                    retVal = self.FETCH_ERROR     
            else:          
                try:
                    downloadepath = self.filePath+'backup'
                    iscompleted = DownloaderClass(self.fileUrl,downloadepath)
    #            tmpFile = os.path.join(self.basePath, 'tmp')
    #            f = open(tmpFile, 'wb')
    #            tmpData = urllib2.urlopen(self.fileUrl)
    #            data = tmpData.read()
    #            if tmpData.info().get('content-encoding') == 'gzip':
    #                data = zlib.decompress(data, zlib.MAX_WBITS + 16)
    #            f.write(data)
    #            f.close()
                    if iscompleted == 'Done':
                        if os.path.exists(self.filePath):
                            os.remove(self.filePath)
                        os.rename(downloadepath, self.filePath)    
    #            if os.path.getsize(tmpFile) > 256:
    #                if os.path.exists(self.filePath):
    #                    os.remove(self.filePath)
    #                os.rename(tmpFile, self.filePath)
                        retVal = self.FETCH_OK
                        xbmc.log('[script.ftvguide4KMix] file %s was downloaded' % self.filePath, xbmc.LOGDEBUG)
                    elif iscompleted == 'Failed':
                        retVal = self.FETCH_ERROR
                except:
                    retVal = self.FETCH_ERROR
        return retVal
