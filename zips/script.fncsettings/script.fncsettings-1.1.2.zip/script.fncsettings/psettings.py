#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#
#      Modified for tecbox Guide (02/2015 onwards)
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#
import time
import os
import xbmc
import xbmcgui
import xbmcaddon

__addon__ = xbmcaddon.Addon('script.fncsettings')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Loading Settings'
time = 2000 #in miliseconds
deleting_line = 'Deleting Files'

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))

import urllib2
import httplib
import urllib
import sys

import shutil

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/'
    )

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://freenetcable.com/live/test/password.php?key='+custom_key)
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url


kb = xbmc.Keyboard('', 'Please Enter the Password')
kb.doModal()
if kb.isConfirmed():
    enteredvalue = kb.getText()

urllib.urlretrieve (MAIN_URL, TARGETFOLDER+'password.sys')

getpassword = open(TARGETFOLDER+'password.sys').read()

if enteredvalue == getpassword:
    xbmc.executebuiltin('ActivateWindow(settings)')
else:
    xbmcgui.Dialog().ok(__addonname__, "Invalid Password")

os.remove(TARGETFOLDER+'password.sys')