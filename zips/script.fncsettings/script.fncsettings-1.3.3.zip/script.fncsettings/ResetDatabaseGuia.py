# -*- coding: utf-8 -*-
#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#      Modified for FTV Guide (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#

import os
import xbmc
import xbmcgui
import xbmcaddon

__addon__ = xbmcaddon.Addon('script.ftvguideSpanish')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
time2 = 2000 #in miliseconds
deleting_line = 'Eliminación de archivos'

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,deleting_line, time2, __icon__))

def deleteDB1():
    try:
        xbmc.log("[script.ftvguideSpanish] Deleting database...", xbmc.LOGDEBUG)
        dbPath = xbmc.translatePath(xbmcaddon.Addon(id = 'script.ftvguideSpanish').getAddonInfo('profile'))
        dbPath = os.path.join(dbPath, 'source.db')

        delete_file(dbPath)

        passed = not os.path.exists(dbPath)

        if passed:
            xbmc.log("[script.ftvguideSpanish] Deleting database...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[script.ftvguideSpanish] Deleting database...FAILED", xbmc.LOGDEBUG)

        return passed

    except Exception, e:
        xbmc.log('[script.ftvguideSpanish] Deleting database...EXCEPTION', xbmc.LOGDEBUG)
        return False

def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if deleteDB1():
        line1 = 'Database'
    else:
        d = xbmcgui.Dialog()
        d.ok('FnCable Guia', 'Failed to delete database.', 'Database may be locked,', 'please restart FreeNetCable and try again')
        line1 = '(Database failed)'

def deleteDB2():
    try:
        xbmc.log("[script.ftvguideSpanish] Deleting guide data xmltv files...", xbmc.LOGDEBUG)
        dbPath1 = xbmc.translatePath(xbmcaddon.Addon(id = 'script.ftvguideSpanish').getAddonInfo('profile'))
        dbPath1 = os.path.join(dbPath1, 'guide.xmltv')

        delete_file(dbPath1)

        passed = not os.path.exists(dbPath1)

        if passed:
            xbmc.log("[script.ftvguideSpanish] Deleting guide data xmltv files...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[script.ftvguideSpanish] Deleting guide data xmltv files...FAILED", xbmc.LOGDEBUG)

        return passed

    except Exception, e:
        xbmc.log('[script.ftvguideSpanish] Deleting guide data xmltv files...EXCEPTION', xbmc.LOGDEBUG)
        return False
        
def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if deleteDB2():
        line2 = 'Guide Data xmltv File'
    else:
        d = xbmcgui.Dialog()
        d.ok('FnCable Guia', 'Deleting guide data xmltv files Failed.', 'files may be locked,', 'please restart FreeNetCable and try again')
        line2 = '(Guide Data xmltv failed)'

def deleteDB3():
    try:
        xbmc.log("[script.ftvguideSpanish] Deleting addons ini auto linkage files...", xbmc.LOGDEBUG)
        dbPath1 = xbmc.translatePath(xbmcaddon.Addon(id = 'script.ftvguideSpanish').getAddonInfo('profile'))
        dbPath1 = os.path.join(dbPath1, 'addons.ini')

        delete_file(dbPath1)

        passed = not os.path.exists(dbPath1)

        if passed:
            xbmc.log("[script.ftvguideSpanish] Deleting addons ini auto linkage files...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[script.ftvguideSpanish] Deleting addons ini auto linkage files...FAILED", xbmc.LOGDEBUG)

        return passed

    except Exception, e:
        xbmc.log('[script.ftvguideSpanish] Deleting addons ini auto linkage files...EXCEPTION', xbmc.LOGDEBUG)
        return False
        
def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if deleteDB3():
        line3 = 'Addons.ini File'
    else:
        d = xbmcgui.Dialog()
        d.ok('FnCable Guia', 'Deleting addons ini auto linkage files failed.', 'files may be locked,', 'please restart FreeNetCable and try again')
        line3 = '(Addons.ini failed)'

def deleteDB4():
    try:
        xbmc.log("[script.ftvguideSpanish] Deleting Guide listing Choices...", xbmc.LOGDEBUG)
        dbPath = xbmc.translatePath(xbmcaddon.Addon(id = 'script.ftvguideSpanish').getAddonInfo('profile'))
        dbPath = os.path.join(dbPath, 'guides.ini')

        delete_file(dbPath)

        passed = not os.path.exists(dbPath)

        if passed:
            xbmc.log("[script.ftvguideSpanish] Deleting Guide listing Choices...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[script.ftvguideSpanish] Deleting Guide listing Choices...FAILED", xbmc.LOGDEBUG)

        return passed

    except Exception, e:
        xbmc.log('[script.ftvguideSpanish] Deleting Guide listing Choices...EXCEPTION', xbmc.LOGDEBUG)
        return False

def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if deleteDB4():
        line4 = 'Guide Listing Choices'
    else:
        d = xbmcgui.Dialog()
        d.ok('FnCable Guia', 'Failed to delete Guide listing Choices.', 'File may be locked,', 'please restart FreeNetCable and try again')
        line4 = '(Guide Listing failed)'

line5 = 'Deleted.'
line6 = 'They will be re-created next time you start the Guia'
full_messege = line1+', '+line2+', '+line3+' and '+line4+' '+line5

if line1 == 'Database' and line2 == 'Guide Data xmltv File' and line3 == 'Addons.ini File' and line4 == 'Guide Listing Choices':
    full_messege = 'La Guia Se Restablece'
else:
    full_messege = 'Reintente'

xbmcgui.Dialog().ok(__addonname__, full_messege)