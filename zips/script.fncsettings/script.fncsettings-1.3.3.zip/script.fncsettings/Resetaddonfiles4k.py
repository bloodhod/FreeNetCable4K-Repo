#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#
#      Modified for tecbox Guide (02/2015 onwards)
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#
import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import os.path as osp
import hashlib
import urllib
import json

import shutil


__addon__ = xbmcaddon.Addon('script.fncsettings')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Successfully Deleted'
line2 = 'Failed'
time = 5000 #in miliseconds
time2 = 2000 #in miliseconds
deleting_line = 'Deleting Files'

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,deleting_line, time2, __icon__))

pDialog = xbmcgui.DialogProgress()
ret = pDialog.create('Reset FnCable', 'Deleting Files')
pDialog.update(25, 'Deleting Files')

custom_key = '0727163831'

custom_mac = 'sha1check'

if __name__ == '__main__':
    try:
        url = 'http://freenetcable.com/rest/api4k.php?type=getfile'
        values = {'username': custom_mac, 'password': custom_key}
        
        #reading response text
        responseText = urllib.urlopen(url, urllib.urlencode(values)).read()
        
        #parsing to json object
        responseObject = json.loads(responseText)
        
        #accessing the required key, and asigning to checksum variable:
        checksum = responseObject['data']['files'][0]['checksum']
        print checksum
    except:
        checksum = '1234566889gfeewfewf'
        pass

originalsha1 = checksum


def write(text):
    """ helper for writing output, as a single point for replacement """
    print(text)

def filehash(filepath):
    blocksize = 64*1024
    sha = hashlib.sha1()
    with open(filepath, 'rb') as fp:
        while True:
            data = fp.read(blocksize)
            if not data:
                break
            sha.update(data)
    return sha.hexdigest() 

TARGETFOLDER = xbmc.translatePath(
    'special://home/addons/packages'
    )

path = TARGETFOLDER

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e
        
    number_of_files = len([item for item in os.listdir(TARGETFOLDER) if os.path.isfile(os.path.join(TARGETFOLDER, item))])

    if number_of_files == 0:
        line4 = 'Addon Packages are Deleted'
    else:
        line4 = 'Addon Package files are Failed to Delete or You have already Deleted the files'
else:
    line4 = 'No Addon Packages Folder'

TARGETFOLDER = xbmc.translatePath(
    'special://home/temp'
    )

path = TARGETFOLDER

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e

    number_of_files = len([item for item in os.listdir(TARGETFOLDER) if os.path.isfile(os.path.join(TARGETFOLDER, item))])

    if number_of_files <= 2:
        line5 = 'Cache Files are Deleted'
    else:
        line5 = 'Cache Files are Failed to Delete or You have already Deleted the files'
else:
    line5 = 'No Cache Folder'

pDialog.update(50, 'Deleting Files')

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/Database'
    )

TARGETFOLDER3 = xbmc.translatePath(
    'special://home/userdata/Database/Addons19.db'
    )

TARGETFOLDER4 = xbmc.translatePath(
    'special://home/userdata/Addons19.db'
    )

path = TARGETFOLDER

folder = TARGETFOLDER

try:
    shutil.copy2(TARGETFOLDER3, TARGETFOLDER4)
except:
    returnedvalue = 'Not worked'
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e
    try:
        shutil.copy2(TARGETFOLDER4, TARGETFOLDER3)
    except: pass
    number_of_files = len([item for item in os.listdir(TARGETFOLDER) if os.path.isfile(os.path.join(TARGETFOLDER, item))])

    if number_of_files <= 6:
        line6 = 'Database Files are Deleted'
    else:
        line6 = 'Database Files are Failed to Delete or You have already Deleted the files'
else:
    line6 = 'No Database Folder'

TARGETFOLDER = xbmc.translatePath(
    '/sdcard/FnCable Update/download'
    )

TARGETFOLDER2 = xbmc.translatePath(
    '/sdcard/FnCable Update/download/'
    )

ROOT = TARGETFOLDER

if os.path.exists(TARGETFOLDER):
    for root, dirs, files in os.walk(ROOT):
        for fpath in [osp.join(root, f) for f in files]:
            size = osp.getsize(fpath)
            sha = filehash(fpath)
            name = osp.relpath(fpath, ROOT)
            if sha == originalsha1:
                newline = 'Matched'
            else:
                try:
                    os.remove(TARGETFOLDER2+name)
                except OSError, e:
                    print ("Error: %s - %s." % (e.filename,e.strerror))
else:
    line7 = ''

TARGETFOLDER = xbmc.translatePath(
    '/sdcard/FNC Restore/download'
    )

pDialog.update(75, 'Deleting Files')

TARGETFOLDER2 = xbmc.translatePath(
    '/sdcard/FNC Restore/download/'
    )

ROOT = TARGETFOLDER

if os.path.exists(TARGETFOLDER):
    for root, dirs, files in os.walk(ROOT):
        for fpath in [osp.join(root, f) for f in files]:
            size = osp.getsize(fpath)
            sha = filehash(fpath)
            name = osp.relpath(fpath, ROOT)
            if sha == originalsha1:
                newline = 'Matched'
            else:
                try:
                    os.remove(TARGETFOLDER2+name)
                except OSError, e:
                    print ("Error: %s - %s." % (e.filename,e.strerror))
else:
    line7 = ''

TARGETFOLDER = xbmc.translatePath(
    '/sdcard/Update/download'
    )

TARGETFOLDER2 = xbmc.translatePath(
    '/sdcard/Update/download/'
    )

ROOT = TARGETFOLDER

if os.path.exists(TARGETFOLDER):
    for root, dirs, files in os.walk(ROOT):
        for fpath in [osp.join(root, f) for f in files]:
            size = osp.getsize(fpath)
            sha = filehash(fpath)
            name = osp.relpath(fpath, ROOT)
            if sha == originalsha1:
                newline = 'Matched'
            else:
                try:
                    os.remove(TARGETFOLDER2+name)
                except OSError, e:
                    print ("Error: %s - %s." % (e.filename,e.strerror))
else:
    line7 = ''

TARGETFOLDER = xbmc.translatePath(
    '/data/data/org.xbmc.kodi/cache'
    )

path = TARGETFOLDER

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e
        
    number_of_files = len([item for item in os.listdir(TARGETFOLDER) if os.path.isfile(os.path.join(TARGETFOLDER, item))])

    if number_of_files <= 0:
        line8 = 'Application Cache Files are Deleted'
    else:
        line8 = 'Application Cache Files are Failed to Delete or You have already Deleted the files'
else:
    line8 = 'No Application Cache Folder'

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/Thumbnails'
    )

path = TARGETFOLDER

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e
        
    number_of_files = len([item for item in os.listdir(TARGETFOLDER) if os.path.isfile(os.path.join(TARGETFOLDER, item))])

    if number_of_files <= 0:
        line9 = 'Thumbnails Files are Deleted'
    else:
        line9 = 'Thumbnails Files are Failed to Delete or You have already Deleted the files'
else:
    line9 = 'No Thumbnails Folder'

FinalLine = 'FnCable Reset.'
FinalLine2 = 'Restart FnCable before use.'

pDialog.update(100, 'Completed')

pDialog.close()

xbmcgui.Dialog().ok(__addonname__, FinalLine, FinalLine2)