#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#
#      Modified for tecbox Guide (02/2015 onwards)
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#

import xbmc
import xbmcgui
import xbmcaddon
import sqlite3
import xbmcplugin
import os
import shutil

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/Database/'
    )

DB_FILE_PATH = TARGETFOLDER+'Epg10.db'

def removeByThreeDots(x):
    return x[:len(x) - x[::-1].find('...')]

if __name__ == '__main__':
    #connecting to database, remeber to enter full path to DB_FILE_PATH, or relative path to the script
    try:
        with sqlite3.connect(DB_FILE_PATH) as connection:
            connection.create_function("removeByThreeDots", 1, removeByThreeDots)
            cursor = connection.cursor()
            
            #updating statement
            cursor.execute("update epgtags set sPlot = removeByThreeDots(sPlot)")
            
            #saving the dbfile
            connection.commit()
        print 'All Done!'
    except: pass

    try:
        with sqlite3.connect(DB_FILE_PATH) as connection:
            cursor = connection.cursor()
            
            #string to remove from epgtags.sPlot column is in the variable stringToRemove
            stringToRemove = 'EPG By Epg.Ninja - Want to help us? find our thread on zeta'
            
            #updating statement
            cursor.execute("update epgtags set sPlot = replace(sPlot,'%s','')"%stringToRemove)
            
            #saving the dbfile
            connection.commit()
        print 'All Done!'
    except: pass

TARGETFOLDER = '/sdcard/OTA-Updater/download/rom'

path = TARGETFOLDER

folder = TARGETFOLDER
if os.path.exists(TARGETFOLDER):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
            donevalue = '1'
        except Exception, e:
            print e