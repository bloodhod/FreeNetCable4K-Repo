import xbmcaddon
import xbmcgui

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
 
line1 = 'You have successfully added '+custom_key
line2 = "Enjoy!!!"

xbmcaddon.Addon().openSettings()

#xbmcgui.Dialog().ok(__addonname__, line1, line2)