import sys
import urllib2
import httplib
import xbmcgui
import urlparse
import xbmcaddon

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)

def open_url(url):
    import requests
    html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
    html = html.text
#    html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
    if '!DOCTYPE html' in html:
        itsdone = 'yes'
    else:
        html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
        html = html.text
#        html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
        if '!DOCTYPE html' in html:
            itsdone = 'yes'
        else:
            html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
            html = html.text
#            html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
            if '!DOCTYPE html' in html:
                itsdone = 'yes'
            else:
                html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                html = html.text
#                html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                if '!DOCTYPE html' in html:
                    itsdone = 'yes'
                else:
                    html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                    html = html.text
#                    html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                    if '!DOCTYPE html' in html:
                        itsdone = 'yes'
                    else:
                        html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                        html = html.text
#                        html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                        if '!DOCTYPE html' in html:
                            itsdone = 'yes'
                        else:
                            html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                            html = html.text
#                            html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                            if '!DOCTYPE html' in html:
                                itsdone = 'yes'
                            else:
                                html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                html = html.text
#                                html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                if '!DOCTYPE html' in html:
                                    itsdone = 'yes'
                                else:
                                    html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                    html = html.text
#                                    html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                    if '!DOCTYPE html' in html:
                                        itsdone = 'yes'
                                    else:
                                        html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                        html = html.text
#                                        html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                        if '!DOCTYPE html' in html:
                                            itsdone = 'yes'
                                        else:
                                            html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                            html = html.text
#                                            html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                            if '!DOCTYPE html' in html:
                                                itsdone = 'yes'
                                            else:
                                                html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                                html = html.text
#                                                html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                                if '!DOCTYPE html' in html:
                                                    itsdone = 'yes'
                                                else:
                                                    html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                                    html = html.text
#                                                    html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                                    if '!DOCTYPE html' in html:
                                                        itsdone = 'yes'
                                                    else:
                                                        html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                                        html = html.text
#                                                        html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
                                                        if '!DOCTYPE html' in html:
                                                            itsdone = 'yes'
                                                        else:
                                                            html = requests.get('http://idragondev.com/webscrap/lib/new.php?url='+url)
                                                            html = html.text
#                                                            html = urllib2.urlopen('http://idragondev.com/webscrap/lib/new.php?url='+url).read()
    return html

def c():
    custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key)
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URL = f.url

    if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
        lineworking = 'Registered'
    else:
        xbmcgui.Dialog().ok('Openload Movies', 'Please Register your CableOi')
        sys.exit(0)

if mode is None:
    c()