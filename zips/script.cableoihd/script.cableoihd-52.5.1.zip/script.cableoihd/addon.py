# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import hashlib
import re
import time
import string
import config
import load_channels
import server



addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') )
__icon__ = addon.getAddonInfo('icon')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;

xbmcplugin.setContent(addon_handle, 'movies')

version = xbmc.getInfoLabel('System.BuildVersion')
version = version.split()


def addPortal(portal):

	if portal['url'] == '':
		return;

	url = build_url({
		'mode': 'genres', 
		'portal' : json.dumps(portal)
		});
	
	cmd = 'XBMC.RunPlugin(' + base_url + '?mode=cache&stalker_url=' + portal['url'] + ')';	
	
	li = xbmcgui.ListItem(portal['name'], iconImage='DefaultProgram.png')
	li.addContextMenuItems([ ('Clear Cache', cmd) ]);

	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
	
def build_url(query):
	return base_url + '?' + urllib.urlencode(query)

def homeLevel():
	global portal_1, portal_2, portal_3, go;
	
	# at least portal 1 will be active.

	if go:
		addPortal(portal_1);
		addPortal(portal_2);
		addPortal(portal_3);
	
		xbmcplugin.endOfDirectory(addon_handle);

def genreLevel():
	
	try:
		data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], portal['login'], portal['password'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		
		return;

	data = data['genres'];

	for id, i in data.iteritems():

		title 	= i["title"];
		title   = string.capwords(title);
		
		url = build_url({
			'mode': 'channels', 
			'genre_id': id, 
			'genre_name': title, 
			'portal' : json.dumps(portal)
			});
		
		if id == '10':
			iconImage = 'OverlayLocked.png';
		else:
			iconImage = 'DefaultVideo.png';
			
		li = xbmcgui.ListItem(title, iconImage=iconImage)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
		
##########
# create VoD folders
	url = build_url({
		'mode': 'vod',
		'cat_id': '10',
		'genre_name': 'VoD',
		'portal' : json.dumps(portal)
		});
		
	li = xbmcgui.ListItem('VoD', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
	

	url = build_url({
		'mode': 'vodspanish', 
		'cat_id': '12',
		'genre_name': 'VoD Espanol',
		'portal' : json.dumps(portal)
		});

	li = xbmcgui.ListItem('VoD Español', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
#
#	url = build_url({
#		'mode': 'English',
#		'genre_name': 'English'
#		});
#		
#	li = xbmcgui.ListItem('English', iconImage='DefaultVideo.png')
#	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
#
#	url = build_url({
#		'mode': 'Spanish',
#		'genre_name': 'Spanish'
#		});
#		
#	li = xbmcgui.ListItem('Spanish', iconImage='DefaultVideo.png')
#	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
#
	url = build_url({
		'mode': 'Search',
		'genre_name': 'Search'
		});
		
	li = xbmcgui.ListItem('Search', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'SearchVOD',
		'genre_name': 'SearchVOD'
		});
		
	li = xbmcgui.ListItem('VOD Search', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'Country',
		'genre_name': 'Country'
		});
		
	li = xbmcgui.ListItem('Country', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'Language',
		'genre_name': 'Language'
		});
		
	li = xbmcgui.ListItem('Language', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'HD',
		'genre_name': 'HD'
		});
		
	li = xbmcgui.ListItem('HD', iconImage='http://icons.iconarchive.com/icons/dan-wiersma/apple-tv/256/HD-icon.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

##########			
		
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);
	xbmcplugin.endOfDirectory(addon_handle);

def CountryList():
	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'AR'
		});
		
	li = xbmcgui.ListItem('Argentina', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'BO'
		});
		
	li = xbmcgui.ListItem('Bolivia', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'CA'
		});
		
	li = xbmcgui.ListItem('Canada', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'CL'
		});
		
	li = xbmcgui.ListItem('Chile', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'CO'
		});
		
	li = xbmcgui.ListItem('Colombia', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'CR'
		});
		
	li = xbmcgui.ListItem('Costa Rica', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'CU'
		});
		
	li = xbmcgui.ListItem('Cuba', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'DO'
		});
		
	li = xbmcgui.ListItem('Dominican Republic', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'SV'
		});
		
	li = xbmcgui.ListItem('El Salvador', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'Greece'
		});
		
	li = xbmcgui.ListItem('Greece', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'GT'
		});
		
	li = xbmcgui.ListItem('Guatemala', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'HN'
		});
		
	li = xbmcgui.ListItem('Honduras', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'HU'
		});
		
	li = xbmcgui.ListItem('Hungary', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'IE'
		});
		
	li = xbmcgui.ListItem('Ireland', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'JM'
		});
		
	li = xbmcgui.ListItem('Jamaica', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'MX'
		});
		
	li = xbmcgui.ListItem('Mexico', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'PA'
		});
		
	li = xbmcgui.ListItem('Panama', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'NI'
		});
		
	li = xbmcgui.ListItem('Nicaragua', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'PE'
		});
		
	li = xbmcgui.ListItem('Peru', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'PY'
		});
		
	li = xbmcgui.ListItem('Paraguay', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'RU'
		});
		
	li = xbmcgui.ListItem('Russia', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'IR'
		});
		
	li = xbmcgui.ListItem('Iran', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'VE'
		});
		
	li = xbmcgui.ListItem('Venezuela', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'US'
		});
		
	li = xbmcgui.ListItem('USA', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'GetCountry',
		'genre_name': 'UK'
		});
		
	li = xbmcgui.ListItem('UK', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

##########			
		
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);
	xbmcplugin.endOfDirectory(addon_handle);

def LanguageList():
	url = build_url({
		'mode': 'Getlanguage',
		'genre_name': 'EN'
		});
		
	li = xbmcgui.ListItem('English', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'Getlanguage',
		'genre_name': 'ES'
		});
		
	li = xbmcgui.ListItem('Spanish', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

	url = build_url({
		'mode': 'Getlanguage',
		'genre_name': 'HU'
		});
		
	li = xbmcgui.ListItem('Hungarian', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);

##########			
		
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL);
	xbmcplugin.endOfDirectory(addon_handle);

def vodLevel():
	
	try:
		data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], portal['login'], portal['password'], portal['vodpages'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;
	
	data = data['vod'];
	genre_name = args.get('genre_name', None);
	genre_name = genre_name[0];
	cat_id_main = args.get('cat_id', None);
	cat_id_main = cat_id_main[0];
	genretypes = json.loads ('{"0":"","1":"Action","2":"2","3":"Documentary","4":"Drama","5":"Family","6":"Romance","7":"Comedy","8":"8","9":"9","10":"Adventure","11":"Thriller","12":"Horror","13":"Sci-Fi","14":"","15":"Fantasy","16":"Animation","17":"Family","18":"Music","19":"Western","20":"20","21":"21","22":"Sport","23":"23","24":"24","25":"25","26":"Short","27":"27","28":"28","29":"29","30":"30"}')
	
	for i in data:
	
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		cat_id  = i["cat_id"];
		genre_1 = i["genre_1"];
		genre_2 = i["genre_2"];
		genre_3 = i["genre_3"];
		genre_4 = i["genre_4"];
		
		genre   = [genretypes[genre_1], genretypes[genre_2], genretypes[genre_3], genretypes[genre_4]]
		genre   = " ".join(genre)
		genre   = genre.rstrip()
		genre   = genre.replace(" ",", ")

		year    = i["year"];
		direct  = i["direct"];
		mpaa    = i["mpaa"];
		runtime = i["runtime"];
		if version[0] >= '16' and runtime != "":
			runtime = str(int(runtime) * 60)
		rating  = i["rating"];
		country = i["country"]
		
		cast    = i["cast"];
		cast    = tuple(cast.split(', '))

		plot    = i["plot"];
		
		if logo != '':
			logo_url = portal['url'] + logo;
		else:
			logo_url = 'DefaultVideo.png';
		
		if cat_id == cat_id_main:
			url = build_url({
				'mode': 'play', 
				'cmd': cmd, 
				'tmp' : '0', 
				'title' : name.encode("utf-8"),
				'genre_name' : genre_name,
				'logo_url' : logo_url, 
				'portal' : json.dumps(portal)
				});

			li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url)
			li.setInfo(type='Video', 
						infoLabels={ 
						"Genre": genre, 
						"Title": name, 
						"Year": year, 
						"Director": direct, 
						"Mpaa": mpaa, 
						"Duration": runtime, 
						"Rating": rating,
						"Country": country,		
						"Cast": cast,  
						"Plot": plot })

			xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE);
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_MPAA_RATING);		
	xbmcplugin.endOfDirectory(addon_handle);

def channelLevel():

	stop=False;
		
	try:
		data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'],portal['login'], portal['password'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;
		
	data = data['channels'];
	genre_name 	= args.get('genre_name', None);	
	genre_id_main = args.get('genre_id', None);
	genre_id_main = genre_id_main[0];
	
	if genre_id_main == '10' and portal['parental'] == 'true':
		result = xbmcgui.Dialog().input('Parental', hashlib.md5(portal['ppassword'].encode('utf-8')).hexdigest(), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY);
		if result == '':
			stop = True;
	
	if stop == False:
		for i in data.values():
			
			name 		= i["name"];
			cmd 		= i["cmd"];
			tmp 		= i["tmp"];
			number 		= i["number"];
			genre_id 	= i["genre_id"];
			logo 		= i["logo"];
		
			if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
				continue;
				
			if genre_id_main == genre_id or genre_id_main == '*':
		
				if logo != '':
					logo_url = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
				else:
					logo_url = 'DefaultVideo.png';
								
				url = build_url({
					'mode': 'play', 
					'cmd': cmd, 
					'tmp' : tmp, 
					'title' : name.encode("utf-8"),
					'genre_name' : genre_name,
					'logo_url' : logo_url,  
					'portal' : json.dumps(portal)
					});
			
				li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url);
				li.setInfo(type='Video', infoLabels={ 
					'title': name,
					'count' : number
					});
				cmd = 'XBMC.RunPlugin(' + base_url + '?mode=report&stalker_url=' + portal['url'] + ')';
				li.addContextMenuItems([ ('Report', cmd) ]);
				xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li);
		
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
			
		xbmcplugin.endOfDirectory(addon_handle);

def playLevel():
	
	dp = xbmcgui.DialogProgressBG();
	dp.create('CableOi', 'Loading ...');
	
	title 	= args['title'][0];
	cmd 	= args['cmd'][0];
	tmp 	= args['tmp'][0];
	genre_name 	= args['genre_name'][0];
	logo_url 	= args['logo_url'][0];

	if genre_name == 'VoD' or genre_name == 'VoD Espanol':
		tmp = "";

	try :
		url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], portal['login'], portal['password'], cmd, tmp);
			
	except Exception as e:
		dp.close();
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;

	
	dp.update(80);
	
	title = title.decode("utf-8");
	
	title += ' (' + portal['name'] + ')';
	
	li = xbmcgui.ListItem(title, iconImage='DefaultVideo.png', thumbnailImage=logo_url);
	li.setInfo('video', {'Title': title, 'Genre': genre_name});
	xbmc.Player().play(item=url, listitem=li);
	
	dp.update(100);
	
	dp.close();

custom_mac = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_mac_1")
custom_server = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_server_1")
if custom_server == '5':
	custom_mac = '00:1A:78:'+custom_mac
	customportalserver = 'http://portal.iptvrocket.tv/'
if custom_server == '6':
	custom_mac = '00:1A:79:'+custom_mac
	customportalserver = 'http://portal1.iptvrocket.tv/'
custom_login = xbmcaddon.Addon('plugin.video.stalker').getSetting("login_1")
custom_portal = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_name_1")

def vodnew():
	
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_vodenglish'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_vodenglish'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)
	
	data = data['vod'];
	genre_name = args.get('genre_name', None);
	genre_name = genre_name[0];
	cat_id_main = args.get('cat_id', None);
	cat_id_main = cat_id_main[0];
	genretypes = json.loads ('{"0":"","1":"Action","2":"2","3":"Documentary","4":"Drama","5":"Family","6":"Romance","7":"Comedy","8":"8","9":"9","10":"Adventure","11":"Thriller","12":"Horror","13":"Sci-Fi","14":"","15":"Fantasy","16":"Animation","17":"Family","18":"Music","19":"Western","20":"20","21":"21","22":"Sport","23":"23","24":"24","25":"25","26":"Short","27":"27","28":"28","29":"29","30":"30"}')
	
	for i in data:
	
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		cat_id  = i["cat_id"];
		genre_1 = i["genre_1"];
		genre_2 = i["genre_2"];
		genre_3 = i["genre_3"];
		genre_4 = i["genre_4"];
		
		genre   = [genretypes[genre_1], genretypes[genre_2], genretypes[genre_3], genretypes[genre_4]]
		genre   = " ".join(genre)
		genre   = genre.rstrip()
		genre   = genre.replace(" ",", ")

		year    = i["year"];
		direct  = i["direct"];
		mpaa    = i["mpaa"];
		runtime = i["runtime"];
		if version[0] >= '16' and runtime != "":
			runtime = str(int(runtime) * 60)
		rating  = i["rating"];
		country = i["country"]
		
		cast    = i["cast"];
		cast    = tuple(cast.split(', '))

		plot    = i["plot"];
		
		if logo != '':
			logo_url = portal['url'] + logo;
		else:
			logo_url = 'DefaultVideo.png';
		
		if cat_id == cat_id_main:
			url = build_url({
				'mode': 'play', 
				'cmd': cmd, 
				'tmp' : '0', 
				'title' : name.encode("utf-8"),
				'genre_name' : genre_name,
				'logo_url' : logo_url, 
				'portal' : json.dumps(portal)
				});

			li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url)
			li.setInfo(type='Video', 
						infoLabels={ 
						"Genre": genre, 
						"Title": name, 
						"Year": year, 
						"Director": direct, 
						"Mpaa": mpaa, 
						"Duration": runtime, 
						"Rating": rating,
						"Country": country,		
						"Cast": cast,  
						"Plot": plot })

			xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.endOfDirectory(addon_handle);

def vodnewspanish():
	
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_vodspanish'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_vodspanish'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)
	
	data = data['vod'];
	genre_name = args.get('genre_name', None);
	genre_name = genre_name[0];
	cat_id_main = args.get('cat_id', None);
	cat_id_main = cat_id_main[0];
	genretypes = json.loads ('{"0":"","1":"Action","2":"2","3":"Documentary","4":"Drama","5":"Family","6":"Romance","7":"Comedy","8":"8","9":"9","10":"Adventure","11":"Thriller","12":"Horror","13":"Sci-Fi","14":"","15":"Fantasy","16":"Animation","17":"Family","18":"Music","19":"Western","20":"20","21":"21","22":"Sport","23":"23","24":"24","25":"25","26":"Short","27":"27","28":"28","29":"29","30":"30"}')
	
	for i in data:
	
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		cat_id  = i["cat_id"];
		genre_1 = i["genre_1"];
		genre_2 = i["genre_2"];
		genre_3 = i["genre_3"];
		genre_4 = i["genre_4"];
		
		genre   = [genretypes[genre_1], genretypes[genre_2], genretypes[genre_3], genretypes[genre_4]]
		genre   = " ".join(genre)
		genre   = genre.rstrip()
		genre   = genre.replace(" ",", ")

		year    = i["year"];
		direct  = i["direct"];
		mpaa    = i["mpaa"];
		runtime = i["runtime"];
		if version[0] >= '16' and runtime != "":
			runtime = str(int(runtime) * 60)
		rating  = i["rating"];
		country = i["country"]
		
		cast    = i["cast"];
		cast    = tuple(cast.split(', '))

		plot    = i["plot"];
		
		if logo != '':
			logo_url = portal['url'] + logo;
		else:
			logo_url = 'DefaultVideo.png';
		
		if cat_id == cat_id_main:
			url = build_url({
				'mode': 'play', 
				'cmd': cmd, 
				'tmp' : '0', 
				'title' : name.encode("utf-8"),
				'genre_name' : genre_name,
				'logo_url' : logo_url, 
				'portal' : json.dumps(portal)
				});

			li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url)
			li.setInfo(type='Video', 
						infoLabels={ 
						"Genre": genre, 
						"Title": name, 
						"Year": year, 
						"Director": direct, 
						"Mpaa": mpaa, 
						"Duration": runtime, 
						"Rating": rating,
						"Country": country,		
						"Cast": cast,  
						"Plot": plot })

			xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.endOfDirectory(addon_handle);

def getcustomserver():
	custom_mac = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_mac_1")
	custom_server = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_server_1")
	if custom_server == '5':
		custom_mac = '00:1A:78:'+custom_mac
		customportalserver = 'http://portal.iptvrocket.tv/'
		customportalserver2 = 'http://portal.iptvrocket.tv'
	if custom_server == '6':
		custom_mac = '00:1A:79:'+custom_mac
		customportalserver = 'http://portal1.iptvrocket.tv/'
		customportalserver2 = 'http://portal.iptvrocket.tv'
	custom_login = xbmcaddon.Addon('plugin.video.stalker').getSetting("login_1")
	custom_portal = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_name_1")
	portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver2+'", "ppassword": "0000", "vodpages": "200", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
	return (customportalserver2, portal_string)

def SearchVOD():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_vodenglish'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_vodenglish'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    customportalserver2, portal_string = getcustomserver()
    kb = xbmc.Keyboard('', 'Enter the Movie Name')
    kb.doModal()
    if kb.isConfirmed():
        enteredvalue = kb.getText()
        enteredvalue1 = enteredvalue[:1].upper() + enteredvalue[1:]
        enteredvalue2 = enteredvalue.upper()
    else:
    	xbmcgui.Dialog().ok(addonname, "Please enter the movie name")
    	sys.exit(0)
    dialog = xbmcgui.Dialog()
    entries = ["English", "Spanish"]
    nr = dialog.select("Select Language", entries)
    if nr>=0:
    	entry = entries[nr]
    else:
    	sys.exit(0)
    if entry == 'English':
    	cat_id_main = '10'
    if entry == 'Spanish':
    	cat_id_main = '12'

    with open(TARGETFOLDER) as js:
        data = json.load(js)

	data = data['vod'];
	genre_name = args.get('genre_name', None);
#	genre_name = genre_name[0];
#	cat_id_main = args.get('cat_id', None);
#	cat_id_main = cat_id_main[0];
#	cat_id_main = '10'
	genretypes = json.loads ('{"0":"","1":"Action","2":"2","3":"Documentary","4":"Drama","5":"Family","6":"Romance","7":"Comedy","8":"8","9":"9","10":"Adventure","11":"Thriller","12":"Horror","13":"Sci-Fi","14":"","15":"Fantasy","16":"Animation","17":"Family","18":"Music","19":"Western","20":"20","21":"21","22":"Sport","23":"23","24":"24","25":"25","26":"Short","27":"27","28":"28","29":"29","30":"30"}')
	
	for i in data:
	
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		cat_id  = i["cat_id"];
		genre_1 = i["genre_1"];
		genre_2 = i["genre_2"];
		genre_3 = i["genre_3"];
		genre_4 = i["genre_4"];
		
		genre   = [genretypes[genre_1], genretypes[genre_2], genretypes[genre_3], genretypes[genre_4]]
		genre   = " ".join(genre)
		genre   = genre.rstrip()
		genre   = genre.replace(" ",", ")

		year    = i["year"];
		direct  = i["direct"];
		mpaa    = i["mpaa"];
		runtime = i["runtime"];
		newname 	= i["name"].encode("utf-8");
		version = '5'
		if version >= '16' and runtime != "":
			runtime = str(int(runtime) * 60)
		rating  = i["rating"];
		country = i["country"]
		
		cast    = i["cast"];
		cast    = tuple(cast.split(', '))

		plot    = i["plot"];
		
		if logo != '':
			logo_url = customportalserver2 + logo;
		else:
			logo_url = 'DefaultVideo.png';
		if  enteredvalue in newname or enteredvalue1 in newname or enteredvalue2 in newname:
			if cat_id == cat_id_main:
				url = build_url({
					'mode': 'play', 
					'cmd': cmd, 
					'tmp' : '0', 
					'title' : name.encode("utf-8"),
					'genre_name' : 'VoD',
					'logo_url' : logo_url, 
					'portal' : portal_string
					});

				li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url)
				li.setInfo(type='Video', 
							infoLabels={ 
							"Genre": genre, 
							"Title": name, 
							"Year": year, 
							"Director": direct, 
							"Mpaa": mpaa, 
							"Duration": runtime, 
							"Rating": rating,
							"Country": country,		
							"Cast": cast,  
							"Plot": plot })

				xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.endOfDirectory(addon_handle);

import sqlite3
import sys

def getCountry(title):
    done = False    
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/Stalker.db'
        )
    if not os.path.exists(TARGETFOLDER):
    	MAIN_URL = 'http://idragonlk.com/FnCable/Stalker.db'
    	urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    conn = sqlite3.connect(TARGETFOLDER)    
    
    cursor = conn.execute("SELECT country from STALKER where channelname is \""+title+"\"")
    for row in cursor:
        print ("country = ", row[0])
        done = True
       
    if done:
        return row[0]
    else:
        return "No entry found for title : "+title
    conn.close()         

def getLanuguage(title):
    done = False    
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/Stalker.db'
        )
    if not os.path.exists(TARGETFOLDER):
    	MAIN_URL = 'http://idragonlk.com/FnCable/Stalker.db'
    	urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    conn = sqlite3.connect(TARGETFOLDER)    
    
    cursor = conn.execute("SELECT language from STALKER where channelname is \""+title+"\"")
    for row in cursor:
        print ("country = ", row[0])
        done = True
       
    if done:
        return row[0]
    else:
        return "No entry found for title : "+title
    conn.close()         

def Englishchannels():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_english'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_english'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
#       title = title.encode("utf-8")
        cmd = v["cmd"]
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'CableOi'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")

#       xbmcgui.Dialog().ok(__addonname__, title)

        liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
        liz.setInfo( type="Video",  infoLabels={ "Title": title} )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Spanishchannels():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_spanish'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_spanish'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
#       title = title.encode("utf-8")
        cmd = v["cmd"]
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'CableOi'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")

#       xbmcgui.Dialog().ok(__addonname__, title)

        liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
        liz.setInfo( type="Video",  infoLabels={ "Title": title} )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Searchchannels():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_all'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_all'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    kb = xbmc.Keyboard('', 'Enter the Channel Name')
    kb.doModal()
    if kb.isConfirmed():
        enteredvalue = kb.getText()
        enteredvalue1 = enteredvalue[:1].upper() + enteredvalue[1:]
        enteredvalue2 = enteredvalue.upper()
    else:
    	xbmcgui.Dialog().ok(addonname, "Please enter the channel name")
    	sys.exit(0)
    with open(TARGETFOLDER) as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
#       title = title.encode("utf-8")
        cmd = v["cmd"]
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'CableOi'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")

#       xbmcgui.Dialog().ok(__addonname__, title)

        if enteredvalue in title or enteredvalue1 in title or enteredvalue2 in title:
            liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
            liz.setInfo( type="Video",  infoLabels={ "Title": title} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def CountryChannels(countryname):
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_all'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_all'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    import codecs
    f = codecs.open(TARGETFOLDER, "r", "utf-8")
    data = json.load(f)
    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
        gottitle = getCountry(title)
#        title2 = v["name"].encode('utf-8')
        cmd = v["cmd"]
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'CableOi'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
#        gottitle = getCountry(title)

#        xbmcgui.Dialog().ok(addonname, countryname)

#       xbmcgui.Dialog().ok(__addonname__, title)
        if countryname == gottitle:
            liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
            liz.setInfo( type="Video",  infoLabels={ "Title": title} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def LanguageChannels(countryname):
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_all'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_all'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    import codecs
    f = codecs.open(TARGETFOLDER, "r", "utf-8")
    data = json.load(f)
    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
        gottitle = getLanuguage(title)
#        title2 = v["name"].encode('utf-8')
        cmd = v["cmd"]
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'CableOi'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")
#        gottitle = getCountry(title)

#        xbmcgui.Dialog().ok(addonname, countryname)

#       xbmcgui.Dialog().ok(__addonname__, title)
        if countryname == gottitle:
            liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
            liz.setInfo( type="Video",  infoLabels={ "Title": title} )
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def channelLevel2():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_all'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_all'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
#       title = title.encode("utf-8")
        cmd = v["cmd"]
        number = v["number"]
        if not number == None:
        	title = number+' - '+title
        logo = v["logo"]
        tmp = v["tmp"]
        genre_title = v["genre_title"]
        url = 'hello'
        portalurl = 'plugin://plugin.video.stalker/?'
        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

        url = portalurl+'tmp='+tmp
        portalname = 'CableOi'
        url = portalurl
        parental = 'false'
        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
        raw_url = raw_url.encode("utf-8")
        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")

#       xbmcgui.Dialog().ok(__addonname__, title)

        liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
        liz.setInfo( type="Video",  infoLabels={ "Title": title} )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def HDList():
    TARGETFOLDER = xbmc.translatePath(
        'special://home/userdata/addon_data/plugin.video.stalker/http_portal_iptvrocket_tv_all'
        )
    MAIN_URL = 'http://idragonlk.com/FnCable/http_portal_iptvrocket_tv_all'
    urllib.urlretrieve (MAIN_URL, TARGETFOLDER)
    stop=False;
    with open(TARGETFOLDER) as js:
        data = json.load(js)

    ch = data["channels"]
    for k,v in ch.items():
        title = v["name"]
        if ' HD' in title and not 'Adult' in title:
#       title = title.encode("utf-8")
	        cmd = v["cmd"]
	        number = v["number"]
	        logo = v["logo"]
	        tmp = v["tmp"]
	        genre_title = v["genre_title"]
	        url = 'hello'
	        portalurl = 'plugin://plugin.video.stalker/?'
	        logo_url =  customportalserver+'stalker_portal/misc/logos/320/' + logo;

	        url = portalurl+'tmp='+tmp
	        portalname = 'CableOi'
	        url = portalurl
	        parental = 'false'
	        portal_string = '{"name": "'+custom_portal+'", "parental": "false", "url": "'+customportalserver+'", "ppassword": "0000", "vodpages": "10", "mac": "'+custom_mac+'", "serial": {"send_serial": true, "custom": false}, "password": "'+custom_login+'", "login": "'+custom_login+'"}'
	        raw_url = "tmp="+tmp+"&genre_name=['All']&title="+title+"&cmd="+cmd+"&portal="+portal_string+"&mode=play&logo_url="+logo_url
	        raw_url = raw_url.encode("utf-8")
	        url = portalurl+urllib.quote_plus(raw_url).replace('%3D','=').replace("%26","&")

	#       xbmcgui.Dialog().ok(__addonname__, title)

	        liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo_url)
	        liz.setInfo( type="Video",  infoLabels={ "Title": title} )
	        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

import resources.lib.requests as requests

def send_simple_message(channelnamereport,reportmac,reportkey):
    return requests.post(
        "https://api.mailgun.net/v3/sandbox7dd9acc5794b4db58b825feed52edd63.mailgun.org/messages",
        auth=("api", "key-7ad5b215c2f72f79f8816d043a5162df"),
        data={"from": "Mailgun Sandbox <postmaster@sandbox7dd9acc5794b4db58b825feed52edd63.mailgun.org>",
              "to": "Nishantha Indika <idragonmain@gmail.com>",
              "subject": "Channel Down",
              "text": channelnamereport+' is down\n\n'+'Mac = '+reportmac+'\nKey = '+reportkey })

mode = args.get('mode', None);

genre_namenew = args.get('genre_name', None);
portal =  args.get('portal', None)

hdstatus = args.get('hdstatus', None);


if portal is None:
	portal_1 = config.portalConfig('1');
	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

else:
#  Force outside call to portal_1
	portal = json.loads(portal[0]);
	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

	if not ( portal['name'] == portal_2['name'] or portal['name'] == portal_3['name'] ) :
		portal = config.portalConfig('1');


if mode is None:
	homeLevel();

elif mode[0] == 'cache':	
	stalker_url = args.get('stalker_url', None);
	stalker_url = stalker_url[0];	
	load_channels.clearCache(stalker_url, addondir);

elif mode[0] == 'report':
	from xbmc import getCondVisibility, getInfoLabel
	try:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__, line5, time, __icon__))
		getethmac = open('/sys/class/net/eth0/address').read()
		custom_key1 = getethmac.replace(':','')
		reportmac = custom_key1[:12]
	except:
		reportmac = 'Mac Address Not Found'
	try:
		reportkey = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")
	except:
		reportkey = 'Key Not Found'
	g_title = getInfoLabel( "ListItem.Label" )
#	xbmcgui.Dialog().ok('__addonname__', g_title)
	send_simple_message(g_title,reportmac,reportkey)
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(addonname, 'Reported', 3000, __icon__))

elif mode[0] == 'genres':
	genreLevel();
		
elif mode[0] == 'vod':
	vodnew();

elif mode[0] == 'vodspanish':
	vodnewspanish();

elif mode[0] == 'channels':
	channelLevel();

elif mode[0] == 'AllByChannelNumber':
	channelLevel2();
	
elif mode[0] == 'play':
	playLevel();

elif mode[0] == 'English':
	Englishchannels();

elif mode[0] == 'Spanish':
	Spanishchannels();

elif mode[0] == 'Search':
	Searchchannels();

elif mode[0] == 'SearchVOD':
	SearchVOD();

elif mode[0] == 'Country':
	CountryList();

elif mode[0] == 'Language':
	LanguageList();

elif mode[0] == 'HD':
	HDList();

elif mode[0] == 'GetCountry':
	countryname = str(genre_namenew)
	countryname = countryname.replace("['", "")
	countryname = countryname.replace("']", "")
	CountryChannels(countryname)

elif mode[0] == 'Getlanguage':
	countryname = str(genre_namenew)
	countryname = countryname.replace("['", "")
	countryname = countryname.replace("']", "")
	LanguageChannels(countryname)
	
elif mode[0] == 'server':
	port = addon.getSetting('server_port');
	
	action =  args.get('action', None);
	action = action[0];
	
	dp = xbmcgui.DialogProgressBG();
	dp.create('M3U Server', 'Working ...');
	
	if action == 'start':
	
		if server.serverOnline():
			xbmcgui.Dialog().notification(addonname, 'Server already started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
		else:
			server.startServer();
			time.sleep(5);
			if server.serverOnline():
				xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
			else:
				xbmcgui.Dialog().notification(addonname, 'Server not started. Wait a minute and try again. ', xbmcgui.NOTIFICATION_ERROR );
				
	else:
		if server.serverOnline():
			server.stopServer();
			time.sleep(5);
			xbmcgui.Dialog().notification(addonname, 'Server stopped.', xbmcgui.NOTIFICATION_INFO );
		else:
			xbmcgui.Dialog().notification(addonname, 'Server is already stopped.', xbmcgui.NOTIFICATION_INFO );
			
	dp.close();
