import sys
import urllib
import urlparse
import xbmcgui
import urllib2
import xbmcplugin
import xbmcaddon
import httplib
import json
from datetime import *
from pytz import timezone
import pytz
import resources.lib.requests as requests
import resources.lib.lxml as lxml
from bs4 import BeautifulSoup

__addon__ = xbmcaddon.Addon('plugin.video.liveshedule')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

imgfolder = xbmc.translatePath(
    'special://home/addons/plugin.video.liveshedule/images/'
    )

xbmcplugin.setContent(addon_handle, 'movies')

fmt = '%Y-%m-%d %I:%M %p'

url = 'http://www.fantasyfootballnerd.com/service/schedule/json/rb4gxsww4iu7/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
values = {'name' : 'Michael Foord',
          'location' : 'Northampton',
          'language' : 'Python' }
headers = { 'User-Agent' : user_agent }

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

def checkregistered():
    httplib.HTTPConnection.debuglevel = 1
    request = urllib2.Request('http://freenetcable.com/live/test/ftvverify.php?key='+custom_key)
    opener = urllib2.build_opener()
    f = opener.open(request)
    MAIN_URL = f.url

    if MAIN_URL == 'http://freenetcable.com/live/test/ftv/':
        lineworking = 'Registered'
    else:
        xbmcgui.Dialog().ok('CableOi Live Schedule', 'Please Register your CableOi')
        sys.exit(0)

def checkteam(awayTeam):
        
        if awayTeam == 'ARI':
                awayTeam = 'Cardinals'
        elif awayTeam == 'ATL':
                awayTeam = 'Falcons'
        elif awayTeam == 'BAL':
                awayTeam = 'Ravens'
        elif awayTeam == 'BUF':
                awayTeam = 'Bills'
        elif awayTeam == 'CAR':
                awayTeam = 'Pan'
        elif awayTeam == 'CHI':
                awayTeam = 'Bears'
        elif awayTeam == 'CIN':
                awayTeam = 'Bengals'
        elif awayTeam == 'CLE':
                awayTeam = 'Browns'
        elif awayTeam == 'DAL':
                awayTeam = 'Cowboys'
        elif awayTeam == 'DEN':
                awayTeam = 'Broncos'
        elif awayTeam == 'DET':
                awayTeam = 'Lions'
        elif awayTeam == 'GB':
                awayTeam = 'Packers'
        elif awayTeam == 'HOU':
                awayTeam = 'Texans'
        elif awayTeam == 'IND':
                awayTeam = 'Colts'
        elif awayTeam == 'JAC':
                awayTeam = 'Jaguars'
        elif awayTeam == 'KC':
                awayTeam = 'Chiefs'
        elif awayTeam == 'MIA':
                awayTeam = 'Dolphins'
        elif awayTeam == 'MIN':
                awayTeam = 'Viking'
        elif awayTeam == 'NYG':
                awayTeam = 'Giants'
        elif awayTeam == 'NYJ':
                awayTeam = 'Jets'
        elif awayTeam == 'NE':
                awayTeam = 'Patriots'
        elif awayTeam == 'NO':
                awayTeam = 'Saints'
        elif awayTeam == 'OAK':
                awayTeam = 'Raiders'
        elif awayTeam == 'PHI':
                awayTeam = 'Eagles'
        elif awayTeam == 'PIT':
                awayTeam = 'Steelers'
        elif awayTeam == 'SD':
                awayTeam = 'Chargers'
        elif awayTeam == 'SF':
                awayTeam = '49ers'
        elif awayTeam == 'SEA':
                awayTeam = 'Seahawks'
        elif awayTeam == 'LA':
                awayTeam = 'Rams'
        elif awayTeam == 'TB':
                awayTeam = 'Buccaneers'
        elif awayTeam == 'TEN':
                awayTeam = 'Titans'
        elif awayTeam == 'WAS':
                awayTeam = 'Redskins'
        else:
                awayTeam = awayTeam
        return awayTeam

def checkteam2(awayTeam):
        
        if awayTeam == 'ARI':
                awayTeam = 'Arizona Cardinals'
        elif awayTeam == 'ATL':
                awayTeam = 'Atlanta Falcons'
        elif awayTeam == 'BAL':
                awayTeam = 'Baltimore Ravens'
        elif awayTeam == 'BUF':
                awayTeam = 'Buffalo Bills'
        elif awayTeam == 'CAR':
                awayTeam = 'Carolina Pan'
        elif awayTeam == 'CHI':
                awayTeam = 'Chicago Bears'
        elif awayTeam == 'CIN':
                awayTeam = 'Cincinnati Bengals'
        elif awayTeam == 'CLE':
                awayTeam = 'Cleveland Browns'
        elif awayTeam == 'DAL':
                awayTeam = 'Dallas Cowboys'
        elif awayTeam == 'DEN':
                awayTeam = 'Denver Broncos'
        elif awayTeam == 'DET':
                awayTeam = 'Detroit Lions'
        elif awayTeam == 'GB':
                awayTeam = 'Green Bay Packers'
        elif awayTeam == 'HOU':
                awayTeam = 'Houston Texans'
        elif awayTeam == 'IND':
                awayTeam = 'Indianapolis Colts'
        elif awayTeam == 'JAC':
                awayTeam = 'Jacksonville Jaguars'
        elif awayTeam == 'KC':
                awayTeam = 'Kansas City Chiefs'
        elif awayTeam == 'MIA':
                awayTeam = 'Miami Dolphins'
        elif awayTeam == 'MIN':
                awayTeam = 'Minnesota Viking'
        elif awayTeam == 'NYG':
                awayTeam = 'N.Y. Giants'
        elif awayTeam == 'NYJ':
                awayTeam = 'N.Y. Jets'
        elif awayTeam == 'NE':
                awayTeam = 'New England Patriots'
        elif awayTeam == 'NO':
                awayTeam = 'New Orleans Saints'
        elif awayTeam == 'OAK':
                awayTeam = 'Oakland Raiders'
        elif awayTeam == 'PHI':
                awayTeam = 'Philadelphia Eagles'
        elif awayTeam == 'PIT':
                awayTeam = 'Pittsburgh Steelers'
        elif awayTeam == 'SD':
                awayTeam = 'San Diego Chargers'
        elif awayTeam == 'SF':
                awayTeam = 'San Francisco 49ers'
        elif awayTeam == 'SEA':
                awayTeam = 'Seattle Seahawks'
        elif awayTeam == 'LA':
                awayTeam = 'Los Angeles Rams'
        elif awayTeam == 'TB':
                awayTeam = 'Tampa Bay Buccaneers'
        elif awayTeam == 'TEN':
                awayTeam = 'Tennessee Titans'
        elif awayTeam == 'WAS':
                awayTeam = 'Washington Redskins'
        else:
                awayTeam = awayTeam
        return awayTeam

def checkname(channel):
    if channel == 'ANIMAL':
        channel = 'Animal Planet'
    elif channel == 'BBC':
        channel = 'BBC America'
    elif channel == 'TOON':
        channel = 'Cartoon Network'
    elif channel == 'MAX':
        channel = 'Cinemax'
    elif channel == 'COMEDY':
        channel = 'Comedy Central'
    elif channel == 'DISNEY':
        channel = 'Disney Channel'
    elif channel == 'DISXD':
        channel = 'Disney XD'
    elif channel == 'DLIF':
        channel = 'Discovery Life'
    elif channel == 'DSC':
        channel = 'Discovery Channel'
    elif channel == 'ESPNCLS':
        channel = 'ESPN Classic Sports'
    elif channel == 'ESQUI':
        channel = 'Esquire TV'
    elif channel == 'FLIXe':
        channel = 'Flix'
    elif channel == 'FNC':
        channel = 'FOX News'
    elif channel == 'FREFM':
        channel = 'Freeform TV'
    elif channel == 'FS1':
        channel = 'FOX Sports 1'
    elif channel == 'HALMRK':
        channel = 'Hallmark'
    elif channel == 'HBOSGe':
        channel = 'HBO Signature'
    elif channel == 'HIST':
        channel = 'History Channel'
    elif channel == 'LIFE':
        channel = 'Lifetime'
    elif channel == 'LRW':
        channel = 'Lifetime Real Women'
    elif channel == 'MAXe':
        channel = 'Cinemax'
    elif channel == 'MOMAX':
        channel = 'More Max'
    elif channel == 'msnbc':
        channel = 'MSNBC'
    elif channel == 'NBCSN':
        channel = 'NBC Sports Network'
    elif channel == 'NGC':
        channel = 'National Geographic Channel'
    elif channel == 'NIK':
        channel = 'Nick'
    elif channel == 'OXYGN':
        channel = 'Oxygen'
    elif channel == 'SCI':
        channel = 'Science Channel'
    elif channel == 'SHO':
        channel = 'Showtime'
    elif channel == 'SHO2e':
        channel = 'Showtime 2'
    elif channel == 'SMITH':
        channel = 'Smithsonian'
    elif channel == 'STZEN':
        channel = 'Starz Encore'
    elif channel == 'SPK':
        channel = 'Spike TV'
    elif channel == 'SUND':
        channel = 'Sundance Channel'
    elif channel == 'USA':
        channel = 'USA Network'
    elif channel == 'WGNA':
        channel = 'WGN America'
    else:
        channel = channel
    return channel

def getsearch(number, keyword):
    url = "http://www.tvguide.com/search/listings/"+number
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"}
    response = requests.get(url, params={"keyword": keyword}, headers=headers)
    soup = BeautifulSoup(response.text, "html5lib")
    no_lists = soup.select(".search-results-listings > p")
    if no_lists:
        name = no_lists[0].text
        no_listsmessage = no_lists[0].text
        no_listsvalue = 'Yes'
    if not no_lists:
        no_listsvalue ='No'
        no_listsmessage = 'No'
        listname = 'List Have'


    items = soup.select(".airing")

    for i in items:
        name = i.select(".airing-details-program-title > a")
        name = name[0].text if name else ""
        sep = i.select(".airing-details-program-number")
        season = sep[0].text.replace("(", "").replace(")", "") if sep else ""
        date = i.select(".airing-date-day")
        date = date[0].text if date else ""
        month = i.select(".airing-date-date")
        month = month[0].text if date else ""
        time = i.select(".airing-date-time")
        time = time[0].text if date else ""
        date = date+' '+month+' '+time
        channel = i.select(".airing-details-channels")
        channel = channel[0].text if channel else ""
        description = i.select(".airing-details-program-description")
        description = description[0].text if description else ""
        channel = checkname(channel)
        if name:
            print(name.encode('utf-8'))
        if date:
            print(date.encode('utf-8'))
        if channel:
            print(channel.encode('utf-8'))
        if description:
            print(description.encode('utf-8'))
        print("\n")
        channelfordb = channel
        foundcount = findcount(channel)
        if foundcount >0:
            channel = '[COLOR lime]'+channel+'[/COLOR]'
        else:
            channel = '[COLOR snow]'+channel+'[/COLOR]'
        fmt = '%Y %b %d %I:%M%p'
        i = datetime.now()
        yearnew = str(i)[:4]
        date = date[4:]
        print(date)
        date = yearnew+' '+date
        gettime = datetime.strptime(date, fmt)
        print(gettime)

    #    gettime = str(gettime)[10:]

    #    gettime = newdate+gettime

        server_timezone = pytz.timezone("EST")
        new_timezone = pytz.timezone("EST")

        gettime = datetime.strptime(str(gettime),"%Y-%m-%d %H:%M:%S")
        # returns datetime in the new timezone. Profit!
        #current_time_in_new_timezone = server_timezone.localize(gettime).astimezone(new_timezone)
        current_time_in_new_timezone = gettime - timedelta(hours=1)
        print(current_time_in_new_timezone)
        time = current_time_in_new_timezone.strftime("%b %d %I:%M %p")
        name = '[COLOR snow]'+name+' '+time+'  CST | '+'[/COLOR]'+channel.encode('utf-8')
        if not season:
            description = '[COLOR snow]'+description+'[/COLOR]'
        else:
            description = '[COLOR snow]'+season+'\n'+description+'[/COLOR]'
        description = description.encode('utf-8')
        if not no_lists:
            url = build_url({'mode': 'play', 'channelname': channelfordb})
            li = xbmcgui.ListItem(name, iconImage=imgfolder+'defaultimg.png')
            li.setInfo( type="Video", infoLabels={ "Title": name, "Plot":description})
            li.setProperty('fanart_image', imgfolder+'background.jpg') 
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    return no_listsvalue, no_listsmessage, name

def getsearchnfl(number, keyword):
    url = "http://www.tvguide.com/search/listings/"+number
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"}
    response = requests.get(url, params={"keyword": keyword}, headers=headers)
    soup = BeautifulSoup(response.text, "html5lib")
    no_lists = soup.select(".search-results-listings > p")
    if no_lists:
        name = no_lists[0].text
        no_listsmessage = no_lists[0].text
        no_listsvalue = 'Yes'
    if not no_lists:
        no_listsvalue ='No'
        no_listsmessage = 'No'
        listname = 'List Have'


    items = soup.select(".airing")

    for i in items:
        name = i.select(".airing-details-program-title > a")
        name = name[0].text if name else ""
        sep = i.select(".airing-details-program-number")
        season = sep[0].text.replace("(", "").replace(")", "") if sep else ""
        date = i.select(".airing-date-day")
        date = date[0].text if date else ""
        month = i.select(".airing-date-date")
        month = month[0].text if date else ""
        time = i.select(".airing-date-time")
        time = time[0].text if date else ""
        date = date+' '+month+' '+time
        channel = i.select(".airing-details-channels")
        channel = channel[0].text if channel else ""
        description = i.select(".airing-details-program-description")
        description = description[0].text if description else ""
        channel = checkname(channel)
        if name:
            print(name.encode('utf-8'))
        if date:
            print(date.encode('utf-8'))
        if channel:
            print(channel.encode('utf-8'))
        if description:
            print(description.encode('utf-8'))
        print("\n")
        channelfordb = channel
        foundcount = findcount(channel)
        if foundcount >0:
            channel = '[COLOR lime]'+channel+'[/COLOR]'
        else:
            channel = '[COLOR snow]'+channel+'[/COLOR]'
        fmt = '%Y %b %d %I:%M%p'
        i = datetime.now()
        yearnew = str(i)[:4]
        date = date[4:]
        print(date)
        date = yearnew+' '+date
        gettime = datetime.strptime(date, fmt)
        print(gettime)

    #    gettime = str(gettime)[10:]

    #    gettime = newdate+gettime

        server_timezone = pytz.timezone("EST")
        new_timezone = pytz.timezone("EST")

        gettime = datetime.strptime(str(gettime),"%Y-%m-%d %H:%M:%S")
        # returns datetime in the new timezone. Profit!
        #current_time_in_new_timezone = server_timezone.localize(gettime).astimezone(new_timezone)
        current_time_in_new_timezone = gettime - timedelta(hours=1)
        print(current_time_in_new_timezone)
        time = current_time_in_new_timezone.strftime("%b %d %I:%M %p")
        name = '[COLOR snow]'+name+' '+time+'  CST | '+'[/COLOR]'+channel.encode('utf-8')
        if not season:
            description = '[COLOR snow]'+description+'[/COLOR]'
        else:
            description = '[COLOR snow]'+season+'\n'+description+'[/COLOR]'
        description = description.encode('utf-8')
        if not no_lists:
            if not 'Car Matchmaker' in name:
                url = build_url({'mode': 'play', 'channelname': channelfordb})
                li = xbmcgui.ListItem(name, iconImage='http://www.userlogos.org/files/logos/Efreak15/NFL%20Logo.png', thumbnailImage='http://www.userlogos.org/files/logos/Efreak15/NFL%20Logo.png')
                li.setInfo( type="Video", infoLabels={ "Title": name, "Plot":description})
                li.setProperty('fanart_image', imgfolder+'background.jpg') 
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    return no_listsvalue, no_listsmessage, name

def getsearchufc(number, keyword):
    url = "http://www.tvguide.com/search/listings/"+number
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"}
    response = requests.get(url, params={"keyword": keyword}, headers=headers)
    soup = BeautifulSoup(response.text, "html5lib")
    no_lists = soup.select(".search-results-listings > p")
    if no_lists:
        name = no_lists[0].text
        no_listsmessage = no_lists[0].text
        no_listsvalue = 'Yes'
    if not no_lists:
        no_listsvalue ='No'
        no_listsmessage = 'No'
        listname = 'List Have'


    items = soup.select(".airing")

    for i in items:
        name = i.select(".airing-details-program-title > a")
        name = name[0].text if name else ""
        sep = i.select(".airing-details-program-number")
        season = sep[0].text.replace("(", "").replace(")", "") if sep else ""
        date = i.select(".airing-date-day")
        date = date[0].text if date else ""
        month = i.select(".airing-date-date")
        month = month[0].text if date else ""
        time = i.select(".airing-date-time")
        time = time[0].text if date else ""
        date = date+' '+month+' '+time
        channel = i.select(".airing-details-channels")
        channel = channel[0].text if channel else ""
        description = i.select(".airing-details-program-description")
        description = description[0].text if description else ""
        channel = checkname(channel)
        if name:
            print(name.encode('utf-8'))
        if date:
            print(date.encode('utf-8'))
        if channel:
            print(channel.encode('utf-8'))
        if description:
            print(description.encode('utf-8'))
        print("\n")
        channelfordb = channel
        foundcount = findcount(channel)
        if foundcount >0:
            channel = '[COLOR lime]'+channel+'[/COLOR]'
        else:
            channel = '[COLOR snow]'+channel+'[/COLOR]'
        fmt = '%Y %b %d %I:%M%p'
        i = datetime.now()
        yearnew = str(i)[:4]
        date = date[4:]
        print(date)
        date = yearnew+' '+date
        gettime = datetime.strptime(date, fmt)
        print(gettime)

    #    gettime = str(gettime)[10:]

    #    gettime = newdate+gettime

        server_timezone = pytz.timezone("EST")
        new_timezone = pytz.timezone("EST")

        gettime = datetime.strptime(str(gettime),"%Y-%m-%d %H:%M:%S")
        # returns datetime in the new timezone. Profit!
        #current_time_in_new_timezone = server_timezone.localize(gettime).astimezone(new_timezone)
        current_time_in_new_timezone = gettime - timedelta(hours=1)
        print(current_time_in_new_timezone)
        time = current_time_in_new_timezone.strftime("%b %d %I:%M %p")
        name = '[COLOR snow]'+name+' '+time+'  CST | '+'[/COLOR]'+channel.encode('utf-8')
        if not season:
            description = '[COLOR snow]'+description+'[/COLOR]'
        else:
            description = '[COLOR snow]'+season+'\n'+description+'[/COLOR]'
        description = description.encode('utf-8')
        if not no_lists:
            url = build_url({'mode': 'play', 'channelname': channelfordb})
            li = xbmcgui.ListItem(name, iconImage='https://yt3.ggpht.com/-QeD1gcM_f7k/AAAAAAAAAAI/AAAAAAAAAAA/RrU6oF2FBU0/s900-c-k-no-mo-rj-c0xffffff/photo.jpg')
            li.setInfo( type="Video", infoLabels={ "Title": name, "Plot":description})
            li.setProperty('fanart_image', imgfolder+'background.jpg') 
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    return no_listsvalue, no_listsmessage, name

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

import sqlite3
def findcount(channel):
    TARGETFOLDER = xbmc.translatePath(
        'special://home/addons/plugin.video.liveshedule/checkchannels.db'
        )
    #Defining the main function
    print("Fetching url from sqlite databases")
    #Placing the file Location
    sqliteFile=TARGETFOLDER
    #Creating the connection
    conn = sqlite3.connect(sqliteFile)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM Channels WHERE Name = '%s'" % channel)
    result=c.fetchone()
    number_of_rows=result[0]
    return number_of_rows

mode = args.get('mode', None)
channelnamemode = args.get('channelname', None)

if mode is None:
    checkregistered()
    url = build_url({'mode': 'newtonight', 'foldername': 'New Tonight'})
    li = xbmcgui.ListItem('[COLOR snow]'+'New Tonight'+'[/COLOR]', iconImage=imgfolder+'newtonight.png')
    li.setProperty('fanart_image', imgfolder+'background.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'trendingtonight', 'foldername': 'Trending Tonight'})
    li = xbmcgui.ListItem('[COLOR snow]'+'Trending Tonight'+'[/COLOR]', iconImage=imgfolder+'trendingtonight.png')
    li.setProperty('fanart_image', imgfolder+'background.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'todaylivesports', 'foldername': 'Today Live Sports'})
    li = xbmcgui.ListItem('[COLOR snow]'+"Today's Live Sports"+'[/COLOR]', iconImage=imgfolder+'todayslivesports.png')
    li.setProperty('fanart_image', imgfolder+'background.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'nfl', 'foldername': 'NFL'})
    li = xbmcgui.ListItem('[COLOR snow]'+'NFL'+'[/COLOR]', iconImage=imgfolder+'nfl.png')
    li.setProperty('fanart_image', imgfolder+'background.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'ufc', 'foldername': 'UFC'})
    li = xbmcgui.ListItem('[COLOR snow]'+'UFC'+'[/COLOR]', iconImage=imgfolder+'ufc.png')
    li.setProperty('fanart_image', imgfolder+'background.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'search', 'foldername': 'Search'})
    li = xbmcgui.ListItem('[COLOR snow]'+'Search'+'[/COLOR]', iconImage=imgfolder+'search.png')
    li.setProperty('fanart_image', imgfolder+'background.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'nfl':
    dialog = xbmcgui.Dialog()
    entries = ["Events", "All"]
    nr = dialog.select("Select List", entries)
    if nr>=0:
        entry = entries[nr]
    else:
        sys.exit(0)
    if entry == 'Events':
        req = urllib2.Request(url, headers={ 'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64' })
        html = urllib2.urlopen(req).read().decode('utf-8')

        team_data = json.loads(html)

        for item in team_data['Schedule']:
                if item["winner"] == '':
                        gamedate = item["gameDate"]
                        gamedateoriginal = item["gameDate"]
                        tvstation = item["tvStation"]
                        awayTeam = item["awayTeam"]
                        homeTeam = item["homeTeam"]
                        gametime = item["gameTimeET"]
                        gamedate = gamedate+' '+gametime
                        unaware_est = datetime.strptime(gamedate, fmt)
                        current_time = unaware_est #system time

                        server_timezone = pytz.timezone("EST")
                        new_timezone = pytz.timezone("EST")
                        
                        # returns datetime in the new timezone. Profit!
                        current_time_in_new_timezone = server_timezone.localize(current_time).astimezone(new_timezone)
                        current_time_in_new_timezone = current_time_in_new_timezone - timedelta(hours=1)
                        newtime = str(current_time_in_new_timezone)[:16]
                        d = datetime.strptime(newtime, "%Y-%m-%d %H:%M")
                        newgametime = d.strftime("%I:%M %p")
                        awayTeam = checkteam(awayTeam)
                        homeTeam = checkteam(homeTeam)
                        teams = awayTeam+' VS '+homeTeam
                        channelfordb = tvstation
                        foundcount = findcount(tvstation)
                        if foundcount >0:
                            tvstation = '[COLOR lime]'+tvstation+'[/COLOR]'
                        else:
                            tvstation = '[COLOR snow]'+tvstation+'[/COLOR]'
                        nflmatch = '[COLOR snow]'+teams+' '+gamedateoriginal+' at '+newgametime+' CST on '+'[/COLOR]'+tvstation
                        print (nflmatch)
                        url = build_url({'mode': 'play', 'channelname': channelfordb})
                        li = xbmcgui.ListItem(nflmatch, iconImage='http://www.userlogos.org/files/logos/Efreak15/NFL%20Logo.png', thumbnailImage='http://www.userlogos.org/files/logos/Efreak15/NFL%20Logo.png')
                        li.setProperty('fanart_image', imgfolder+'background.jpg') 
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    elif entry == 'All':
        keyword = 'NFL'
        no_listsvalue, no_listsmessage, name = getsearchnfl('', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('2/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('3/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('4/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('5/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('6/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('7/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('8/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('9/', keyword)

        no_listsvalue, no_listsmessage, name = getsearchnfl('10/', keyword)

        if no_listsvalue == 'Yes':
            li = xbmcgui.ListItem('[COLOR snow]'+name+'[/COLOR]', iconImage=imgfolder+'defaultimg.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li)
    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'ufc':
    keyword = 'UFC'
    no_listsvalue, no_listsmessage, name = getsearchufc('', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('2/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('3/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('4/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('5/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('6/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('7/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('8/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('9/', keyword)

    no_listsvalue, no_listsmessage, name = getsearchufc('10/', keyword)

    if no_listsvalue == 'Yes':
        li = xbmcgui.ListItem('[COLOR snow]'+name+'[/COLOR]', iconImage=imgfolder+'defaultimg.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li)

    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'newtonight':
    dialog = xbmcgui.Dialog()
    entries = ["Today", "Tomorrow"]
    nr = dialog.select("Select Day", entries)
    if nr>=0:
        entry = entries[nr]
    else:
        sys.exit(0)
    if entry == 'Today':
        url = "http://www.tvguide.com/new-tonight/"
    elif entry == 'Tomorrow':
        url = 'http://www.tvguide.com/new-tonight/all-shows/tomorrow/'
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html5lib")
    items = soup.select(".listings-program")

    for i in items:
        name = i.select(".listings-program-title")
        name = [x for x in name[0].children][0].text if name else ""
        sep = i.select(".listings-program-episode-chronology")
        sep = sep[0].text.replace("(", "").replace(")", "").split(" | ") if sep else ""
        season = sep[0] if sep else ""
        episode = sep[1] if sep else ""
        info = i.select(".listings-program-airing-info")
        info = info[0].text.split(" | ") if info else ""
        time = info[0] if info else ""
        channel = info[1] if info else ""
        description = i.select(".listings-program-description")
        description = description[0].text if description else ""
        img_url = i.select(".show-card-image")
        img_url = img_url[0].get("src") if img_url else ""
        img_url = img_url if img_url else imgfolder+'defaultimg.png'
        channel = checkname(channel)
        if name:
            print(name.encode('utf-8'))
        if time:
            print(time.encode('utf-8'))
        if channel:
            print(channel.encode('utf-8'))
        if description:
            print(description.encode('utf-8'))
        if img_url:
            print(img_url.encode('utf-8'))
#        xbmcgui.Dialog().ok('__addonname__', name)
        print("\n")
        channelfordb = channel
        foundcount = findcount(channel)
        if foundcount >0:
            channel = '[COLOR lime]'+channel+'[/COLOR]'
        else:
            channel = '[COLOR snow]'+channel+'[/COLOR]'
        fmt = '%I:%M%p'
        i = datetime.now()
        newdate = str(i)[:10]

        gettime = datetime.strptime(time, fmt)

        gettime = str(gettime)[10:]

        gettime = newdate+gettime

        server_timezone = pytz.timezone("EST")
        new_timezone = pytz.timezone("EST")

        gettime = datetime.strptime(gettime,"%Y-%m-%d %H:%M:%S")
        # returns datetime in the new timezone. Profit!
        #current_time_in_new_timezone = server_timezone.localize(gettime).astimezone(new_timezone)
        current_time_in_new_timezone = gettime - timedelta(hours=1)
        print(current_time_in_new_timezone)
        time = current_time_in_new_timezone.strftime("%I:%M %p")
        name = '[COLOR snow]'+name+' '+time+'  CST | '+'[/COLOR]'+channel
        name = name.encode('utf-8')
        if not season:
            description = '[COLOR snow]'+description+'[/COLOR]'
        else:
            description = '[COLOR snow]'+season+' '+episode+'\n'+description+'[/COLOR]'
        description = description.encode('utf-8')
        url = build_url({'mode': 'play', 'channelname': channelfordb})
        li = xbmcgui.ListItem(name, iconImage=img_url)
        li.setInfo( type="Video", infoLabels={ "Title": name, "Plot":description})
        li.setProperty('fanart_image', imgfolder+'background.jpg') 
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'trendingtonight':
    url = "http://www.tvguide.com/trending-tonight/"
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html5lib")
    items = soup.select(".listings-program")

    for i in items:
        name = i.select(".listings-program-title")
        name = [x for x in name[0].children][0].text if name else ""
        sep = i.select(".listings-program-episode-chronology")
        sep = sep[0].text.replace("(", "").replace(")", "").split(" | ") if sep else ""
        season = sep[0] if sep else ""
        episode = sep[1] if sep else ""
        info = i.select(".listings-program-airing-info")
        info = info[0].text.split(" | ") if info else ""
        time = info[0] if info else ""
        channel = info[1] if info else ""
        description = i.select(".listings-program-description")
        description = description[0].text if description else ""
        img_url = i.select(".show-card-image")
        img_url = img_url[0].get("src") if img_url else ""
        img_url = img_url if img_url else imgfolder+'defaultimg.png'
        channel = checkname(channel)
        if name:
            print(name.encode('utf-8'))
        if time:
            print(time.encode('utf-8'))
        if channel:
            print(channel.encode('utf-8'))
        if description:
            print(description.encode('utf-8'))
        if img_url:
            print(img_url.encode('utf-8'))
#        xbmcgui.Dialog().ok('__addonname__', name)
        print("\n")
        channelfordb = channel
        foundcount = findcount(channel)
        if foundcount >0:
            channel = '[COLOR lime]'+channel+'[/COLOR]'
        else:
            channel = '[COLOR snow]'+channel+'[/COLOR]'
        fmt = '%I:%M%p'
        i = datetime.now()
        newdate = str(i)[:10]

        gettime = datetime.strptime(time, fmt)

        gettime = str(gettime)[10:]

        gettime = newdate+gettime

        server_timezone = pytz.timezone("EST")
        new_timezone = pytz.timezone("EST")

        gettime = datetime.strptime(gettime,"%Y-%m-%d %H:%M:%S")
        # returns datetime in the new timezone. Profit!
        #current_time_in_new_timezone = server_timezone.localize(gettime).astimezone(new_timezone)
        current_time_in_new_timezone = gettime - timedelta(hours=1)
        print(current_time_in_new_timezone)
        time = current_time_in_new_timezone.strftime("%I:%M %p")
        name = '[COLOR snow]'+name+' '+time+'  CST | '+'[/COLOR]'+channel
        name = name.encode('utf-8')
        if not season:
            description = '[COLOR snow]'+description+'[/COLOR]'
        else:
            description = '[COLOR snow]'+season+' '+episode+'\n'+description+'[/COLOR]'
        description = description.encode('utf-8')
        url = build_url({'mode': 'play', 'channelname': channelfordb})
        li = xbmcgui.ListItem(name, iconImage=img_url)
        li.setInfo( type="Video", infoLabels={ "Title": name, "Plot":description})
        li.setProperty('fanart_image', imgfolder+'background.jpg') 
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'todaylivesports':
    url = "http://www.tvguide.com/sports/live-today/"
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html5lib")
    items = soup.select(".listings-program")

    for i in items:
        name = i.select(".listings-program-title")
        name = [x for x in name[0].children][0].text if name else ""
        sep = i.select(".listings-program-episode-chronology")
        sep = sep[0].text.replace("(", "").replace(")", "").split(" | ") if sep else ""
        season = sep[0] if sep else ""
        episode = sep[1] if sep else ""
        info = i.select(".listings-program-airing-info")
        info = info[0].text.split(" | ") if info else ""
        time = info[0] if info else ""
        channel = info[1] if info else ""
        description = i.select(".listings-program-description")
        description = description[0].text if description else ""
        img_url = i.select(".show-card-image")
        img_url = img_url[0].get("src") if img_url else ""
        img_url = img_url if img_url else imgfolder+'defaultimg.png'
        channel = checkname(channel)
        if name:
            print(name.encode('utf-8'))
        if time:
            print(time.encode('utf-8'))
        if channel:
            print(channel.encode('utf-8'))
        if description:
            print(description.encode('utf-8'))
        if img_url:
            print(img_url.encode('utf-8'))
#        xbmcgui.Dialog().ok('__addonname__', name)
        print("\n")
        channelfordb = channel
        foundcount = findcount(channel)
        if foundcount >0:
            channel = '[COLOR lime]'+channel+'[/COLOR]'
        else:
            channel = '[COLOR snow]'+channel+'[/COLOR]'
        fmt = '%I:%M%p'
        i = datetime.now()
        newdate = str(i)[:10]

        gettime = datetime.strptime(time, fmt)

        gettime = str(gettime)[10:]

        gettime = newdate+gettime

        server_timezone = pytz.timezone("EST")
        new_timezone = pytz.timezone("EST")

        gettime = datetime.strptime(gettime,"%Y-%m-%d %H:%M:%S")
        # returns datetime in the new timezone. Profit!
        #current_time_in_new_timezone = server_timezone.localize(gettime).astimezone(new_timezone)
        current_time_in_new_timezone = gettime - timedelta(hours=1)
        print(current_time_in_new_timezone)
        time = current_time_in_new_timezone.strftime("%I:%M %p")
        name = '[COLOR snow]'+name+' '+time+'  CST | '+'[/COLOR]'+channel
        name = name.encode('utf-8')
        if not season:
            description = '[COLOR snow]'+description+'[/COLOR]'
        else:
            description = '[COLOR snow]'+season+' '+episode+'\n'+description+'[/COLOR]'
        description = description.encode('utf-8')
        url = build_url({'mode': 'play', 'channelname': channelfordb})
        li = xbmcgui.ListItem(name, iconImage=img_url)
        li.setInfo( type="Video", infoLabels={ "Title": name, "Plot":description})
        li.setProperty('fanart_image', imgfolder+'background.jpg') 
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'search':
    kb = xbmc.Keyboard('', 'Enter the Name')
    kb.doModal()
    if kb.isConfirmed():
        keyword = kb.getText()
    else:
        sys.exit(0)

    no_listsvalue, no_listsmessage, name = getsearch('', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('2/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('3/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('4/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('5/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('6/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('7/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('8/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('9/', keyword)

    no_listsvalue, no_listsmessage, name = getsearch('10/', keyword)

    if no_listsvalue == 'Yes':
        li = xbmcgui.ListItem('[COLOR snow]'+name+'[/COLOR]', iconImage=imgfolder+'defaultimg.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li)
    
    xbmc.executebuiltin("Container.SetViewMode(510)")
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'play':
    import sqlite3
    custom_mac = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_mac_1")
    custom_login = xbmcaddon.Addon('plugin.video.stalker').getSetting("login_1")
    custom_password = xbmcaddon.Addon('plugin.video.stalker').getSetting("password_1")
    custom_server = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_server_1")
    if custom_server == '5':
      custom_mac = '00:1A:78:'+custom_mac
      customportalserver = 'portal.iptvrocket.tv'
    if custom_server == '6':
      custom_mac = '00:1A:79:'+custom_mac
      customportalserver = 'portal1.iptvrocket.tv'
    channel = channelnamemode[0]
    TARGETFOLDER = xbmc.translatePath(
        'special://home/addons/plugin.video.liveshedule/checkchannels.db'
        )
    #Defining the main function
    print("Fetching url from sqlite databases")
    #Placing the file Location
    sqliteFile=TARGETFOLDER
    #Creating the connection
    conn = sqlite3.connect(sqliteFile)
    c = conn.cursor()
    # c.execute('''SELECT URL FROM Channels WHERE Name LIKE '%ABC%'
    #         ''')
    # conn.commit()
    res_quality = []
    stream_url = []
    newurl = ''
#    xbmcgui.Dialog().ok('__addonname__', str(channelnamemode[0]))
    for row in c.execute("SELECT URL, LinkName FROM Channels WHERE Name = '%s'" % channel):
        foundurl = row[1]
        foundstream = row[0]
        res_quality.append(foundurl)
        print(newurl)
        stream_url.append(foundstream)
    #Or You can use this

    #print c.fetchall()
    conn.close()
    if len(res_quality)==1:
        url = stream_url[0]
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'Loading', 200, __icon__))
        listItem = xbmcgui.ListItem("Tesfilm", path=url)
        xbmc.Player().play(item=url, listitem=listItem)
    elif len(res_quality)>1:
        dialog = xbmcgui.Dialog()
        nr = dialog.select("Select Stream", res_quality)
        if nr>=0:
            url = stream_url[nr]
            url = url.replace('123456789123', custom_login)
            url = url.replace('00%3A11%3A22%3A33%3A44%3A55', custom_mac)
            url = url.replace('portal.iptvrocket.tv', customportalserver)
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'Loading', 200, __icon__))
            listItem = xbmcgui.ListItem("Tesfilm", path=url)
            xbmc.Player().play(item=url, listitem=listItem)
    else:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'No Stream Found', 200, __icon__))